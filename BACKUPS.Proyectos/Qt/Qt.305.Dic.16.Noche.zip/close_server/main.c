// FIFO
#include <sys/types.h>
#include <sys/stat.h>
#define FIFO_NAME "/home/cha/UTN FRBA/info2_Proyecto_2018/Qt Interfaz PC/american_maid"
#define SALIR "salir"
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(){    
    char code = 'c';

    mkfifo(FIFO_NAME, 0666);

    printf("esperando que corra el server...\n");
    int fd;
    fd = open(FIFO_NAME, O_WRONLY);
    // Si pasa esa línea ya se desbloqueó porque se corrió el server
    printf("server corriendo!\n");
    printf("Presione una tecla para cerrar el server.\n");

    char input;
    scanf("%c", &input);
    // si psa el scanf ya se desbloquea
    write(fd , &code, sizeof(char)*1 );
    close(fd);

    return 0;
}
