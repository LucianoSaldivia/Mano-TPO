/****************************************************************************
** Meta object code from reading C++ file 'mano_animatronica_aplicacion.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Proyecto_Version_03/mano_animatronica_aplicacion.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mano_animatronica_aplicacion.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Mano_Animatronica_Aplicacion_t {
    QByteArrayData data[44];
    char stringdata0[827];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Mano_Animatronica_Aplicacion_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Mano_Animatronica_Aplicacion_t qt_meta_stringdata_Mano_Animatronica_Aplicacion = {
    {
QT_MOC_LITERAL(0, 0, 28), // "Mano_Animatronica_Aplicacion"
QT_MOC_LITERAL(1, 29, 21), // "SerialPort_Initialize"
QT_MOC_LITERAL(2, 51, 0), // ""
QT_MOC_LITERAL(3, 52, 26), // "GUI_Start_Tab_Comunicacion"
QT_MOC_LITERAL(4, 79, 23), // "GUI_Start_Tab_Controles"
QT_MOC_LITERAL(5, 103, 33), // "on_cBx_Puerto_currentIndexCha..."
QT_MOC_LITERAL(6, 137, 5), // "index"
QT_MOC_LITERAL(7, 143, 28), // "on_pushB_Prueba_UART_clicked"
QT_MOC_LITERAL(8, 172, 28), // "on_pushB_Prueba_WIFI_clicked"
QT_MOC_LITERAL(9, 201, 21), // "on_Timer_WIFI_timeout"
QT_MOC_LITERAL(10, 223, 18), // "handler_Error_UART"
QT_MOC_LITERAL(11, 242, 28), // "QSerialPort::SerialPortError"
QT_MOC_LITERAL(12, 271, 5), // "error"
QT_MOC_LITERAL(13, 277, 17), // "handler_ReadyRead"
QT_MOC_LITERAL(14, 295, 18), // "Actualizar_Puertos"
QT_MOC_LITERAL(15, 314, 18), // "Setup_Modo_Ninguno"
QT_MOC_LITERAL(16, 333, 20), // "Setup_Modo_Guante_PC"
QT_MOC_LITERAL(17, 354, 18), // "Setup_Modo_PC_Mano"
QT_MOC_LITERAL(18, 373, 22), // "Setup_Modo_Guante_Mano"
QT_MOC_LITERAL(19, 396, 21), // "on_cBx_Modo_activated"
QT_MOC_LITERAL(20, 418, 24), // "on_rdB_Guante_PC_clicked"
QT_MOC_LITERAL(21, 443, 22), // "on_rdB_PC_Mano_clicked"
QT_MOC_LITERAL(22, 466, 26), // "on_rdB_Guante_Mano_clicked"
QT_MOC_LITERAL(23, 493, 25), // "on_sld_Menor_valueChanged"
QT_MOC_LITERAL(24, 519, 5), // "value"
QT_MOC_LITERAL(25, 525, 26), // "on_sld_Anular_valueChanged"
QT_MOC_LITERAL(26, 552, 25), // "on_sld_Mayor_valueChanged"
QT_MOC_LITERAL(27, 578, 26), // "on_sld_Indice_valueChanged"
QT_MOC_LITERAL(28, 605, 26), // "on_sld_Pulgar_valueChanged"
QT_MOC_LITERAL(29, 632, 26), // "on_pushB_PlayPause_clicked"
QT_MOC_LITERAL(30, 659, 24), // "on_pushB_Guardar_clicked"
QT_MOC_LITERAL(31, 684, 23), // "on_pushB_Cargar_clicked"
QT_MOC_LITERAL(32, 708, 19), // "SendLoadedMovements"
QT_MOC_LITERAL(33, 728, 16), // "InterpretarDatos"
QT_MOC_LITERAL(34, 745, 8), // "uint8_t*"
QT_MOC_LITERAL(35, 754, 3), // "aux"
QT_MOC_LITERAL(36, 758, 4), // "int*"
QT_MOC_LITERAL(37, 763, 5), // "menor"
QT_MOC_LITERAL(38, 769, 6), // "anular"
QT_MOC_LITERAL(39, 776, 5), // "mayor"
QT_MOC_LITERAL(40, 782, 6), // "indice"
QT_MOC_LITERAL(41, 789, 6), // "pulgar"
QT_MOC_LITERAL(42, 796, 17), // "ActualizarSliders"
QT_MOC_LITERAL(43, 814, 12) // "ResetSliders"

    },
    "Mano_Animatronica_Aplicacion\0"
    "SerialPort_Initialize\0\0"
    "GUI_Start_Tab_Comunicacion\0"
    "GUI_Start_Tab_Controles\0"
    "on_cBx_Puerto_currentIndexChanged\0"
    "index\0on_pushB_Prueba_UART_clicked\0"
    "on_pushB_Prueba_WIFI_clicked\0"
    "on_Timer_WIFI_timeout\0handler_Error_UART\0"
    "QSerialPort::SerialPortError\0error\0"
    "handler_ReadyRead\0Actualizar_Puertos\0"
    "Setup_Modo_Ninguno\0Setup_Modo_Guante_PC\0"
    "Setup_Modo_PC_Mano\0Setup_Modo_Guante_Mano\0"
    "on_cBx_Modo_activated\0on_rdB_Guante_PC_clicked\0"
    "on_rdB_PC_Mano_clicked\0"
    "on_rdB_Guante_Mano_clicked\0"
    "on_sld_Menor_valueChanged\0value\0"
    "on_sld_Anular_valueChanged\0"
    "on_sld_Mayor_valueChanged\0"
    "on_sld_Indice_valueChanged\0"
    "on_sld_Pulgar_valueChanged\0"
    "on_pushB_PlayPause_clicked\0"
    "on_pushB_Guardar_clicked\0"
    "on_pushB_Cargar_clicked\0SendLoadedMovements\0"
    "InterpretarDatos\0uint8_t*\0aux\0int*\0"
    "menor\0anular\0mayor\0indice\0pulgar\0"
    "ActualizarSliders\0ResetSliders"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Mano_Animatronica_Aplicacion[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  164,    2, 0x08 /* Private */,
       3,    0,  165,    2, 0x08 /* Private */,
       4,    0,  166,    2, 0x08 /* Private */,
       5,    1,  167,    2, 0x08 /* Private */,
       7,    0,  170,    2, 0x08 /* Private */,
       8,    0,  171,    2, 0x08 /* Private */,
       9,    0,  172,    2, 0x08 /* Private */,
      10,    1,  173,    2, 0x08 /* Private */,
      13,    0,  176,    2, 0x08 /* Private */,
      14,    0,  177,    2, 0x08 /* Private */,
      15,    0,  178,    2, 0x08 /* Private */,
      16,    0,  179,    2, 0x08 /* Private */,
      17,    0,  180,    2, 0x08 /* Private */,
      18,    0,  181,    2, 0x08 /* Private */,
      19,    1,  182,    2, 0x08 /* Private */,
      20,    0,  185,    2, 0x08 /* Private */,
      21,    0,  186,    2, 0x08 /* Private */,
      22,    0,  187,    2, 0x08 /* Private */,
      23,    1,  188,    2, 0x08 /* Private */,
      25,    1,  191,    2, 0x08 /* Private */,
      26,    1,  194,    2, 0x08 /* Private */,
      27,    1,  197,    2, 0x08 /* Private */,
      28,    1,  200,    2, 0x08 /* Private */,
      29,    0,  203,    2, 0x08 /* Private */,
      30,    0,  204,    2, 0x08 /* Private */,
      31,    0,  205,    2, 0x08 /* Private */,
      32,    0,  206,    2, 0x08 /* Private */,
      33,    6,  207,    2, 0x08 /* Private */,
      42,    5,  220,    2, 0x08 /* Private */,
      43,    0,  231,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 34, 0x80000000 | 36, 0x80000000 | 36, 0x80000000 | 36, 0x80000000 | 36, 0x80000000 | 36,   35,   37,   38,   39,   40,   41,
    QMetaType::Void, 0x80000000 | 36, 0x80000000 | 36, 0x80000000 | 36, 0x80000000 | 36, 0x80000000 | 36,   37,   38,   39,   40,   41,
    QMetaType::Void,

       0        // eod
};

void Mano_Animatronica_Aplicacion::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Mano_Animatronica_Aplicacion *_t = static_cast<Mano_Animatronica_Aplicacion *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SerialPort_Initialize(); break;
        case 1: _t->GUI_Start_Tab_Comunicacion(); break;
        case 2: _t->GUI_Start_Tab_Controles(); break;
        case 3: _t->on_cBx_Puerto_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_pushB_Prueba_UART_clicked(); break;
        case 5: _t->on_pushB_Prueba_WIFI_clicked(); break;
        case 6: _t->on_Timer_WIFI_timeout(); break;
        case 7: _t->handler_Error_UART((*reinterpret_cast< QSerialPort::SerialPortError(*)>(_a[1]))); break;
        case 8: _t->handler_ReadyRead(); break;
        case 9: _t->Actualizar_Puertos(); break;
        case 10: _t->Setup_Modo_Ninguno(); break;
        case 11: _t->Setup_Modo_Guante_PC(); break;
        case 12: _t->Setup_Modo_PC_Mano(); break;
        case 13: _t->Setup_Modo_Guante_Mano(); break;
        case 14: _t->on_cBx_Modo_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_rdB_Guante_PC_clicked(); break;
        case 16: _t->on_rdB_PC_Mano_clicked(); break;
        case 17: _t->on_rdB_Guante_Mano_clicked(); break;
        case 18: _t->on_sld_Menor_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_sld_Anular_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_sld_Mayor_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_sld_Indice_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_sld_Pulgar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_pushB_PlayPause_clicked(); break;
        case 24: _t->on_pushB_Guardar_clicked(); break;
        case 25: _t->on_pushB_Cargar_clicked(); break;
        case 26: _t->SendLoadedMovements(); break;
        case 27: _t->InterpretarDatos((*reinterpret_cast< uint8_t*(*)>(_a[1])),(*reinterpret_cast< int*(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3])),(*reinterpret_cast< int*(*)>(_a[4])),(*reinterpret_cast< int*(*)>(_a[5])),(*reinterpret_cast< int*(*)>(_a[6]))); break;
        case 28: _t->ActualizarSliders((*reinterpret_cast< int*(*)>(_a[1])),(*reinterpret_cast< int*(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3])),(*reinterpret_cast< int*(*)>(_a[4])),(*reinterpret_cast< int*(*)>(_a[5]))); break;
        case 29: _t->ResetSliders(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Mano_Animatronica_Aplicacion::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Mano_Animatronica_Aplicacion.data,
      qt_meta_data_Mano_Animatronica_Aplicacion,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Mano_Animatronica_Aplicacion::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Mano_Animatronica_Aplicacion::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Mano_Animatronica_Aplicacion.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Mano_Animatronica_Aplicacion::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 30;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
