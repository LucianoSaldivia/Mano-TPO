/********************************************************************************
** Form generated from reading UI file 'mano_animatronica_aplicacion.ui'
**
** Created by: Qt User Interface Compiler version 5.11.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANO_ANIMATRONICA_APLICACION_H
#define UI_MANO_ANIMATRONICA_APLICACION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Mano_Animatronica_Aplicacion
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab_Comunicacion;
    QGroupBox *grB_Con_WIFI;
    QPushButton *pushB_Prueba_WIFI;
    QLabel *lbl_Estado_Con_WIFI;
    QGroupBox *grB_Com_UART;
    QLabel *lbl_Titulo_Puerto;
    QPushButton *pushB_Actualizar;
    QComboBox *cBx_Puerto;
    QPushButton *pushB_Prueba_UART;
    QLabel *lbl_Estado_Con_UART;
    QLabel *lbl_Titulo_Estado_UART;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *VLyt_Config;
    QLabel *lbl_BaudRate;
    QLabel *lbl_DataBits;
    QLabel *lbl_FlowControl;
    QLabel *lbl_StopBits;
    QLabel *lbl_Parity;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *VLyt_Info;
    QLabel *lbl_UART_Des;
    QLabel *lbl_UART_Fab;
    QLabel *lbl_UART_Nsr;
    QLabel *lbl_UART_Ubi;
    QLabel *lbl_Titulo_Config;
    QLabel *lbl_Titulo_Info;
    QWidget *tab_Controles;
    QPushButton *pushB_PlayPause;
    QLabel *lbl_Archivo;
    QPushButton *pushB_Cargar;
    QGroupBox *grB_Sliders;
    QSlider *sld_Mayor;
    QSlider *sld_Anular;
    QSlider *sld_Menor;
    QSlider *sld_Pulgar;
    QSlider *sld_Indice;
    QLabel *lbl_Sliders;
    QGroupBox *grB_Modo;
    QRadioButton *rdB_Guante_PC;
    QRadioButton *rdB_PC_Mano;
    QRadioButton *rdB_Guante_Mano;
    QGroupBox *grB_Valores;
    QLabel *lbl_VMenor;
    QLabel *lbl_VAnular;
    QLabel *lbl_VMayor;
    QLabel *lbl_VIndice;
    QLabel *lbl_VPulgar;
    QGroupBox *grB_Mano;
    QLabel *lbl_1_Base_Img;
    QLabel *lbl_2_Menor_Img;
    QLabel *lbl_3_Anular_Img;
    QLabel *lbl_4_Mayor_Img;
    QLabel *lbl_5_Indice_Img;
    QLabel *lbl_6_Pulgar_Img;
    QPushButton *pushB_Guardar;
    QSlider *sld_PC_Mano_Control;
    QLabel *lbl_Title;
    QLabel *lbl_InfoII;
    QLabel *lbl_Names;
    QLabel *lbl_sld_Control_File;
    QLabel *lbl_sld_Control_sliders;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Mano_Animatronica_Aplicacion)
    {
        if (Mano_Animatronica_Aplicacion->objectName().isEmpty())
            Mano_Animatronica_Aplicacion->setObjectName(QStringLiteral("Mano_Animatronica_Aplicacion"));
        Mano_Animatronica_Aplicacion->resize(884, 580);
        centralWidget = new QWidget(Mano_Animatronica_Aplicacion);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 0, 861, 551));
        tab_Comunicacion = new QWidget();
        tab_Comunicacion->setObjectName(QStringLiteral("tab_Comunicacion"));
        grB_Con_WIFI = new QGroupBox(tab_Comunicacion);
        grB_Con_WIFI->setObjectName(QStringLiteral("grB_Con_WIFI"));
        grB_Con_WIFI->setGeometry(QRect(90, 310, 660, 201));
        pushB_Prueba_WIFI = new QPushButton(grB_Con_WIFI);
        pushB_Prueba_WIFI->setObjectName(QStringLiteral("pushB_Prueba_WIFI"));
        pushB_Prueba_WIFI->setGeometry(QRect(60, 90, 201, 61));
        lbl_Estado_Con_WIFI = new QLabel(grB_Con_WIFI);
        lbl_Estado_Con_WIFI->setObjectName(QStringLiteral("lbl_Estado_Con_WIFI"));
        lbl_Estado_Con_WIFI->setGeometry(QRect(370, 90, 201, 61));
        lbl_Estado_Con_WIFI->setAlignment(Qt::AlignCenter);
        grB_Com_UART = new QGroupBox(tab_Comunicacion);
        grB_Com_UART->setObjectName(QStringLiteral("grB_Com_UART"));
        grB_Com_UART->setGeometry(QRect(90, 10, 661, 291));
        lbl_Titulo_Puerto = new QLabel(grB_Com_UART);
        lbl_Titulo_Puerto->setObjectName(QStringLiteral("lbl_Titulo_Puerto"));
        lbl_Titulo_Puerto->setGeometry(QRect(20, 50, 61, 16));
        pushB_Actualizar = new QPushButton(grB_Com_UART);
        pushB_Actualizar->setObjectName(QStringLiteral("pushB_Actualizar"));
        pushB_Actualizar->setGeometry(QRect(180, 80, 121, 31));
        cBx_Puerto = new QComboBox(grB_Com_UART);
        cBx_Puerto->setObjectName(QStringLiteral("cBx_Puerto"));
        cBx_Puerto->setGeometry(QRect(20, 80, 151, 31));
        pushB_Prueba_UART = new QPushButton(grB_Com_UART);
        pushB_Prueba_UART->setObjectName(QStringLiteral("pushB_Prueba_UART"));
        pushB_Prueba_UART->setGeometry(QRect(180, 180, 121, 71));
        lbl_Estado_Con_UART = new QLabel(grB_Com_UART);
        lbl_Estado_Con_UART->setObjectName(QStringLiteral("lbl_Estado_Con_UART"));
        lbl_Estado_Con_UART->setGeometry(QRect(20, 180, 151, 71));
        lbl_Estado_Con_UART->setFocusPolicy(Qt::NoFocus);
        lbl_Estado_Con_UART->setLayoutDirection(Qt::LeftToRight);
        lbl_Estado_Con_UART->setAlignment(Qt::AlignCenter);
        lbl_Titulo_Estado_UART = new QLabel(grB_Com_UART);
        lbl_Titulo_Estado_UART->setObjectName(QStringLiteral("lbl_Titulo_Estado_UART"));
        lbl_Titulo_Estado_UART->setGeometry(QRect(20, 150, 151, 16));
        verticalLayoutWidget_4 = new QWidget(grB_Com_UART);
        verticalLayoutWidget_4->setObjectName(QStringLiteral("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(320, 170, 301, 111));
        VLyt_Config = new QVBoxLayout(verticalLayoutWidget_4);
        VLyt_Config->setSpacing(6);
        VLyt_Config->setContentsMargins(11, 11, 11, 11);
        VLyt_Config->setObjectName(QStringLiteral("VLyt_Config"));
        VLyt_Config->setContentsMargins(0, 0, 0, 0);
        lbl_BaudRate = new QLabel(verticalLayoutWidget_4);
        lbl_BaudRate->setObjectName(QStringLiteral("lbl_BaudRate"));

        VLyt_Config->addWidget(lbl_BaudRate);

        lbl_DataBits = new QLabel(verticalLayoutWidget_4);
        lbl_DataBits->setObjectName(QStringLiteral("lbl_DataBits"));

        VLyt_Config->addWidget(lbl_DataBits);

        lbl_FlowControl = new QLabel(verticalLayoutWidget_4);
        lbl_FlowControl->setObjectName(QStringLiteral("lbl_FlowControl"));

        VLyt_Config->addWidget(lbl_FlowControl);

        lbl_StopBits = new QLabel(verticalLayoutWidget_4);
        lbl_StopBits->setObjectName(QStringLiteral("lbl_StopBits"));

        VLyt_Config->addWidget(lbl_StopBits);

        lbl_Parity = new QLabel(verticalLayoutWidget_4);
        lbl_Parity->setObjectName(QStringLiteral("lbl_Parity"));

        VLyt_Config->addWidget(lbl_Parity);

        verticalLayoutWidget_3 = new QWidget(grB_Com_UART);
        verticalLayoutWidget_3->setObjectName(QStringLiteral("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(320, 50, 301, 92));
        VLyt_Info = new QVBoxLayout(verticalLayoutWidget_3);
        VLyt_Info->setSpacing(6);
        VLyt_Info->setContentsMargins(11, 11, 11, 11);
        VLyt_Info->setObjectName(QStringLiteral("VLyt_Info"));
        VLyt_Info->setContentsMargins(0, 0, 0, 0);
        lbl_UART_Des = new QLabel(verticalLayoutWidget_3);
        lbl_UART_Des->setObjectName(QStringLiteral("lbl_UART_Des"));

        VLyt_Info->addWidget(lbl_UART_Des);

        lbl_UART_Fab = new QLabel(verticalLayoutWidget_3);
        lbl_UART_Fab->setObjectName(QStringLiteral("lbl_UART_Fab"));

        VLyt_Info->addWidget(lbl_UART_Fab);

        lbl_UART_Nsr = new QLabel(verticalLayoutWidget_3);
        lbl_UART_Nsr->setObjectName(QStringLiteral("lbl_UART_Nsr"));

        VLyt_Info->addWidget(lbl_UART_Nsr);

        lbl_UART_Ubi = new QLabel(verticalLayoutWidget_3);
        lbl_UART_Ubi->setObjectName(QStringLiteral("lbl_UART_Ubi"));

        VLyt_Info->addWidget(lbl_UART_Ubi);

        lbl_Titulo_Config = new QLabel(grB_Com_UART);
        lbl_Titulo_Config->setObjectName(QStringLiteral("lbl_Titulo_Config"));
        lbl_Titulo_Config->setGeometry(QRect(320, 150, 91, 16));
        lbl_Titulo_Info = new QLabel(grB_Com_UART);
        lbl_Titulo_Info->setObjectName(QStringLiteral("lbl_Titulo_Info"));
        lbl_Titulo_Info->setGeometry(QRect(320, 30, 151, 16));
        tabWidget->addTab(tab_Comunicacion, QString());
        tab_Controles = new QWidget();
        tab_Controles->setObjectName(QStringLiteral("tab_Controles"));
        pushB_PlayPause = new QPushButton(tab_Controles);
        pushB_PlayPause->setObjectName(QStringLiteral("pushB_PlayPause"));
        pushB_PlayPause->setGeometry(QRect(410, 90, 141, 61));
        lbl_Archivo = new QLabel(tab_Controles);
        lbl_Archivo->setObjectName(QStringLiteral("lbl_Archivo"));
        lbl_Archivo->setGeometry(QRect(590, 10, 191, 31));
        pushB_Cargar = new QPushButton(tab_Controles);
        pushB_Cargar->setObjectName(QStringLiteral("pushB_Cargar"));
        pushB_Cargar->setGeometry(QRect(50, 380, 131, 61));
        grB_Sliders = new QGroupBox(tab_Controles);
        grB_Sliders->setObjectName(QStringLiteral("grB_Sliders"));
        grB_Sliders->setGeometry(QRect(240, 150, 321, 311));
        sld_Mayor = new QSlider(grB_Sliders);
        sld_Mayor->setObjectName(QStringLiteral("sld_Mayor"));
        sld_Mayor->setGeometry(QRect(150, 59, 20, 241));
        sld_Mayor->setMaximum(1000);
        sld_Mayor->setOrientation(Qt::Vertical);
        sld_Mayor->setInvertedAppearance(true);
        sld_Anular = new QSlider(grB_Sliders);
        sld_Anular->setObjectName(QStringLiteral("sld_Anular"));
        sld_Anular->setGeometry(QRect(90, 59, 20, 241));
        sld_Anular->setMaximum(1000);
        sld_Anular->setOrientation(Qt::Vertical);
        sld_Anular->setInvertedAppearance(true);
        sld_Menor = new QSlider(grB_Sliders);
        sld_Menor->setObjectName(QStringLiteral("sld_Menor"));
        sld_Menor->setGeometry(QRect(30, 59, 20, 241));
        sld_Menor->setMaximum(1000);
        sld_Menor->setOrientation(Qt::Vertical);
        sld_Menor->setInvertedAppearance(true);
        sld_Pulgar = new QSlider(grB_Sliders);
        sld_Pulgar->setObjectName(QStringLiteral("sld_Pulgar"));
        sld_Pulgar->setGeometry(QRect(270, 59, 16, 241));
        sld_Pulgar->setMaximum(1000);
        sld_Pulgar->setOrientation(Qt::Vertical);
        sld_Pulgar->setInvertedAppearance(true);
        sld_Indice = new QSlider(grB_Sliders);
        sld_Indice->setObjectName(QStringLiteral("sld_Indice"));
        sld_Indice->setGeometry(QRect(210, 59, 16, 241));
        sld_Indice->setMaximum(1000);
        sld_Indice->setOrientation(Qt::Vertical);
        sld_Indice->setInvertedAppearance(true);
        lbl_Sliders = new QLabel(grB_Sliders);
        lbl_Sliders->setObjectName(QStringLiteral("lbl_Sliders"));
        lbl_Sliders->setGeometry(QRect(20, 30, 281, 20));
        grB_Modo = new QGroupBox(tab_Controles);
        grB_Modo->setObjectName(QStringLiteral("grB_Modo"));
        grB_Modo->setGeometry(QRect(20, 150, 191, 121));
        rdB_Guante_PC = new QRadioButton(grB_Modo);
        rdB_Guante_PC->setObjectName(QStringLiteral("rdB_Guante_PC"));
        rdB_Guante_PC->setGeometry(QRect(20, 30, 111, 31));
        rdB_PC_Mano = new QRadioButton(grB_Modo);
        rdB_PC_Mano->setObjectName(QStringLiteral("rdB_PC_Mano"));
        rdB_PC_Mano->setGeometry(QRect(20, 60, 111, 31));
        rdB_Guante_Mano = new QRadioButton(grB_Modo);
        rdB_Guante_Mano->setObjectName(QStringLiteral("rdB_Guante_Mano"));
        rdB_Guante_Mano->setGeometry(QRect(20, 90, 181, 31));
        grB_Valores = new QGroupBox(tab_Controles);
        grB_Valores->setObjectName(QStringLiteral("grB_Valores"));
        grB_Valores->setGeometry(QRect(20, 460, 811, 51));
        lbl_VMenor = new QLabel(grB_Valores);
        lbl_VMenor->setObjectName(QStringLiteral("lbl_VMenor"));
        lbl_VMenor->setGeometry(QRect(40, 20, 91, 31));
        lbl_VAnular = new QLabel(grB_Valores);
        lbl_VAnular->setObjectName(QStringLiteral("lbl_VAnular"));
        lbl_VAnular->setGeometry(QRect(160, 20, 91, 31));
        lbl_VMayor = new QLabel(grB_Valores);
        lbl_VMayor->setObjectName(QStringLiteral("lbl_VMayor"));
        lbl_VMayor->setGeometry(QRect(280, 20, 91, 31));
        lbl_VIndice = new QLabel(grB_Valores);
        lbl_VIndice->setObjectName(QStringLiteral("lbl_VIndice"));
        lbl_VIndice->setGeometry(QRect(400, 20, 91, 31));
        lbl_VPulgar = new QLabel(grB_Valores);
        lbl_VPulgar->setObjectName(QStringLiteral("lbl_VPulgar"));
        lbl_VPulgar->setGeometry(QRect(520, 20, 91, 31));
        grB_Mano = new QGroupBox(tab_Controles);
        grB_Mano->setObjectName(QStringLiteral("grB_Mano"));
        grB_Mano->setGeometry(QRect(590, 50, 241, 411));
        lbl_1_Base_Img = new QLabel(grB_Mano);
        lbl_1_Base_Img->setObjectName(QStringLiteral("lbl_1_Base_Img"));
        lbl_1_Base_Img->setGeometry(QRect(10, 20, 216, 384));
        lbl_2_Menor_Img = new QLabel(grB_Mano);
        lbl_2_Menor_Img->setObjectName(QStringLiteral("lbl_2_Menor_Img"));
        lbl_2_Menor_Img->setGeometry(QRect(10, 20, 216, 384));
        lbl_3_Anular_Img = new QLabel(grB_Mano);
        lbl_3_Anular_Img->setObjectName(QStringLiteral("lbl_3_Anular_Img"));
        lbl_3_Anular_Img->setGeometry(QRect(10, 20, 216, 384));
        lbl_4_Mayor_Img = new QLabel(grB_Mano);
        lbl_4_Mayor_Img->setObjectName(QStringLiteral("lbl_4_Mayor_Img"));
        lbl_4_Mayor_Img->setGeometry(QRect(10, 20, 216, 384));
        lbl_5_Indice_Img = new QLabel(grB_Mano);
        lbl_5_Indice_Img->setObjectName(QStringLiteral("lbl_5_Indice_Img"));
        lbl_5_Indice_Img->setGeometry(QRect(10, 20, 216, 384));
        lbl_6_Pulgar_Img = new QLabel(grB_Mano);
        lbl_6_Pulgar_Img->setObjectName(QStringLiteral("lbl_6_Pulgar_Img"));
        lbl_6_Pulgar_Img->setGeometry(QRect(10, 20, 216, 384));
        pushB_Guardar = new QPushButton(tab_Controles);
        pushB_Guardar->setObjectName(QStringLiteral("pushB_Guardar"));
        pushB_Guardar->setGeometry(QRect(50, 290, 131, 61));
        sld_PC_Mano_Control = new QSlider(tab_Controles);
        sld_PC_Mano_Control->setObjectName(QStringLiteral("sld_PC_Mano_Control"));
        sld_PC_Mano_Control->setGeometry(QRect(440, 20, 91, 31));
        sld_PC_Mano_Control->setSizeIncrement(QSize(0, 0));
        sld_PC_Mano_Control->setAutoFillBackground(false);
        sld_PC_Mano_Control->setMaximum(1);
        sld_PC_Mano_Control->setPageStep(1);
        sld_PC_Mano_Control->setOrientation(Qt::Horizontal);
        sld_PC_Mano_Control->setInvertedAppearance(false);
        sld_PC_Mano_Control->setInvertedControls(false);
        lbl_Title = new QLabel(tab_Controles);
        lbl_Title->setObjectName(QStringLiteral("lbl_Title"));
        lbl_Title->setGeometry(QRect(30, 10, 341, 51));
        lbl_Title->setTextFormat(Qt::AutoText);
        lbl_InfoII = new QLabel(tab_Controles);
        lbl_InfoII->setObjectName(QStringLiteral("lbl_InfoII"));
        lbl_InfoII->setGeometry(QRect(30, 70, 341, 21));
        lbl_InfoII->setLineWidth(1);
        lbl_Names = new QLabel(tab_Controles);
        lbl_Names->setObjectName(QStringLiteral("lbl_Names"));
        lbl_Names->setGeometry(QRect(30, 110, 341, 21));
        lbl_sld_Control_File = new QLabel(tab_Controles);
        lbl_sld_Control_File->setObjectName(QStringLiteral("lbl_sld_Control_File"));
        lbl_sld_Control_File->setGeometry(QRect(410, 50, 64, 18));
        lbl_sld_Control_File->setAlignment(Qt::AlignCenter);
        lbl_sld_Control_sliders = new QLabel(tab_Controles);
        lbl_sld_Control_sliders->setObjectName(QStringLiteral("lbl_sld_Control_sliders"));
        lbl_sld_Control_sliders->setGeometry(QRect(480, 50, 91, 20));
        lbl_sld_Control_sliders->setAlignment(Qt::AlignCenter);
        tabWidget->addTab(tab_Controles, QString());
        Mano_Animatronica_Aplicacion->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(Mano_Animatronica_Aplicacion);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Mano_Animatronica_Aplicacion->setStatusBar(statusBar);

        retranslateUi(Mano_Animatronica_Aplicacion);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Mano_Animatronica_Aplicacion);
    } // setupUi

    void retranslateUi(QMainWindow *Mano_Animatronica_Aplicacion)
    {
        Mano_Animatronica_Aplicacion->setWindowTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Mano_Animatronica_Aplicacion", nullptr));
        grB_Con_WIFI->setTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Conexi\303\263n Wi-Fi", nullptr));
        pushB_Prueba_WIFI->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Comprobar conexi\303\263n \n"
" del Puerto Wi-Fi configurado", nullptr));
        lbl_Estado_Con_WIFI->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Desconectado", nullptr));
        grB_Com_UART->setTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Conexi\303\263n UART", nullptr));
        lbl_Titulo_Puerto->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Puerto", nullptr));
        pushB_Actualizar->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Actualizar", nullptr));
        pushB_Prueba_UART->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Conectar", nullptr));
        lbl_Estado_Con_UART->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Desconectado", nullptr));
        lbl_Titulo_Estado_UART->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Estado de la conexi\303\263n", nullptr));
        lbl_BaudRate->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Taza de Baudios: ", nullptr));
        lbl_DataBits->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Bits de Datos: ", nullptr));
        lbl_FlowControl->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Control de Flujo: ", nullptr));
        lbl_StopBits->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Bits de Stop: ", nullptr));
        lbl_Parity->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Paridad: ", nullptr));
        lbl_UART_Des->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Descripci\303\263n:", nullptr));
        lbl_UART_Fab->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Fabricante:", nullptr));
        lbl_UART_Nsr->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "N\303\272m.Serie:", nullptr));
        lbl_UART_Ubi->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Ubicaci\303\263n:", nullptr));
        lbl_Titulo_Config->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Configuracion", nullptr));
        lbl_Titulo_Info->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Informacion del puerto", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_Comunicacion), QApplication::translate("Mano_Animatronica_Aplicacion", "Comunicaci\303\263n", nullptr));
        pushB_PlayPause->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Play / Pause", nullptr));
        lbl_Archivo->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Nombre_archivo.hnd", nullptr));
        pushB_Cargar->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Cargar \n"
" Movimientos", nullptr));
        grB_Sliders->setTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Sliders", nullptr));
        lbl_Sliders->setText(QApplication::translate("Mano_Animatronica_Aplicacion", " Menor     Anular     Mayor      Incide      Pulgar", nullptr));
        grB_Modo->setTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Modo de Operaci\303\263n", nullptr));
        rdB_Guante_PC->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Guante -> PC", nullptr));
        rdB_PC_Mano->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "PC -> Mano", nullptr));
        rdB_Guante_Mano->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Guante -> Mano", nullptr));
        grB_Valores->setTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Valores actuales", nullptr));
        lbl_VMenor->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Menor : 0", nullptr));
        lbl_VAnular->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Anular : 0", nullptr));
        lbl_VMayor->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Mayor : 0", nullptr));
        lbl_VIndice->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Indice : 0", nullptr));
        lbl_VPulgar->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Pulgar : 0", nullptr));
        grB_Mano->setTitle(QApplication::translate("Mano_Animatronica_Aplicacion", "Mano", nullptr));
        lbl_1_Base_Img->setText(QString());
        lbl_2_Menor_Img->setText(QString());
        lbl_3_Anular_Img->setText(QString());
        lbl_4_Mayor_Img->setText(QString());
        lbl_5_Indice_Img->setText(QString());
        lbl_6_Pulgar_Img->setText(QString());
        pushB_Guardar->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Guardar \n"
" Movimientos", nullptr));
        lbl_Title->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Title", nullptr));
        lbl_InfoII->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Subtitle", nullptr));
        lbl_Names->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "Names", nullptr));
        lbl_sld_Control_File->setText(QApplication::translate("Mano_Animatronica_Aplicacion", ".mno file", nullptr));
        lbl_sld_Control_sliders->setText(QApplication::translate("Mano_Animatronica_Aplicacion", "sliders", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_Controles), QApplication::translate("Mano_Animatronica_Aplicacion", "Controles", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Mano_Animatronica_Aplicacion: public Ui_Mano_Animatronica_Aplicacion {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANO_ANIMATRONICA_APLICACION_H
