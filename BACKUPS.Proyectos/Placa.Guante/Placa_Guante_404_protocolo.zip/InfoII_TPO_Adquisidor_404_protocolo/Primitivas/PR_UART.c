/*******************************************************************************************************************************//**
 *
 * @file		PR_UART.c
 * @brief		Descripcion del modulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include <string.h>
#include <stdio.h>
#include "../inc/PR_UART.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define ESPERANDO_INICIO        0
#define ESPERANDO_SIGUIENTE     1
#define ESPERANDO_COMANDO       2
#define ESPERANDO_DATO          3
#define LLEGO_CR                4

#define CHAR_INICIAL_COMANDO    '$'
#define CHAR_FINAL_COMANDO      '#'
#define CHAR_INICIAL_DATO       '#'
#define CHAR_FINAL_DATO         '$'
#define SIZE_STRING_DATO		14
#define SIZE_STRING_COMANDO		4


#define CANT_COMANDOS           10

#define SIZE_OF_MENSAJE         512

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

volatile const char *Tabla_Comandos_ESP8266[ CANT_COMANDOS ];

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

volatile static uint8_t ESP8266_Inicializado = 0;
volatile static uint8_t Estado_Conexion_WIFI = AUN_NO_INICIALIZADO;

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

/*  FUNCIONES PARA UART3    */

//!< Funcion para escribir un byte a UART3
void UART3_PushTx( int8_t dato ){

    U3_Buf_TX[ U3_Index_In_Tx ] = dato;
    U3_Index_In_Tx ++;
    U3_Index_In_Tx %= U3_MAX_TX;

    if (U3_TxEnCurso == 0) {    // Si no había una TX en curso
        U3_TxEnCurso = 1;       // pongo una TX en curso y
        UART3_StartTx();        // fuerzo el inicio de la TX
    }
}

//!< Funcion para leer un byte desde UART3
int8_t UART3_PopRx( void ){

    int8_t dato = BUFFER_VACIO;

    if ( U3_Index_In_Rx != U3_Index_Out_Rx ){
        dato = U3_Buf_RX[ U3_Index_Out_Rx ];
        U3_Index_Out_Rx ++;
        U3_Index_Out_Rx %= U3_MAX_RX;
    }
    return dato;
}

//!< Funcion para Transmitir datos en crudo por UART3
int8_t UART3_Transmitir( const void *Mensaje, uint16_t Size ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( Size >= U3_MAX_TX ){
        return BUFFER_OVERSIZE;
    }

    for( InxAux = 0; InxAux < Size; InxAux++){
        UART3_PushTx( mensaje[ InxAux ] );
    }

    return ENVIADO;
}

//!< Funcion para Transmitir un string UART_3
int8_t UART3_Transmitir_String( int8_t *mensaje ){

    uint32_t InxAux;

    if( mensaje[0] == '\0' ){
        return BUFFER_VACIO;
    }

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){
        UART3_PushTx( mensaje[ InxAux ] );
    }
    UART3_PushTx( '\0' );

    return ENVIADO;
}

//!< Funcion para recibir un string desde UART3
int8_t UART3_Recibir_String( int8_t *Mensaje, uint32_t Cant_Max ){

    static uint32_t InxAux = 0;
    int8_t dato;

    dato = UART3_PopRx();

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    if( dato != '\0' ){
        if( InxAux != Cant_Max - 1 ){
            Mensaje[InxAux] = dato;
            InxAux ++;
            return RECIBIENDO_MENSAJE;
        }
        else{
            Mensaje[InxAux] = '\0';
            InxAux = 0;
            return MENSAJE_RECIBIDO_CORTADO;
        }
    }
    else{
        Mensaje[InxAux] = '\0';
        InxAux = 0;
        return MENSAJE_RECIBIDO_COMPLETO;
    }
}

//!< Funcion para Transmitir un mensaje como Char_Inicial + Mensaje + Char_Final por UART3
int8_t UART3_Transmitir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( mensaje[0] == '\0' ){    // Si el mensaje está vacío
        return BUFFER_VACIO;
    }

    if( strlen( mensaje ) > U3_MAX_TX - 2 ){   // Si mensaje es mas largo que UN_MAX_TX
        return BUFFER_OVERSIZE;
    }

    UART3_PushTx( Char_Inicial );   // Transmito Char_Inicial

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){    // Transmito Mensaje
        UART3_PushTx( mensaje[ InxAux ] );
    }

    UART3_PushTx( Char_Final );     // Transmito Char_Final

    return ENVIADO;
}

//!< Funcion (Máquina de estados) para recibir un mensaje desde Char_Inicial hasta Char_Final desde UART3
int8_t UART3_Recibir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final ){

    static uint8_t Estado = ESPERANDO_INICIO;
    static uint32_t InxAux = 0;
    int8_t *buf = (int8_t *) Mensaje;
    int8_t dato;


    dato = UART3_PopRx( );

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == Char_Inicial ){
                Estado = ESPERANDO_SIGUIENTE;
                return RECIBIENDO_MENSAJE;
            }
            else return RECIBI_BASURA;
            break;

        case ESPERANDO_SIGUIENTE:
            if( dato != Char_Final ){
                if( InxAux != MAX_TRAMA_RECIBIDA - 1 ){
                    buf[InxAux] = dato;
                    InxAux ++;
                    return RECIBIENDO_MENSAJE;
                }
                else{
                    buf[InxAux] = '\0';
                    Estado = ESPERANDO_INICIO;
                    InxAux = 0;
                    return MENSAJE_RECIBIDO_CORTADO;
                }
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                return MENSAJE_RECIBIDO_COMPLETO;
            }
            break;

        default:
            Estado = ESPERANDO_INICIO;
            return RECIBI_BASURA;
            break;
    }
}

//!< Funcion (Máquina de estados) para recibir un Dato o un Comando de ancho fijo por UART3
int8_t UART3_Recibir_Dato_o_Comando( const void *Mensaje ){
    static uint8_t Estado = ESPERANDO_INICIO;
    static uint16_t InxAux = 0;
    int8_t *buf;
    int8_t dato;

    dato = UART3_PopRx();

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    buf = ( int8_t * ) Mensaje;

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == CHAR_INICIAL_COMANDO ){
                Estado = ESPERANDO_COMANDO;
                return RECIBIENDO_MENSAJE;
            }
            else if( dato == CHAR_INICIAL_DATO ){
                Estado = ESPERANDO_DATO;
                return RECIBIENDO_MENSAJE;
            }
            else return RECIBI_BASURA;
            break;

        case ESPERANDO_COMANDO:
            if( InxAux < SIZE_STRING_COMANDO ){
                buf[InxAux] = dato;
                InxAux ++;
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                if( dato == CHAR_FINAL_COMANDO ){
                    return COMANDO_RECIBIDO;
                }
                else return MENSAJE_RECIBIDO_CORTADO;
            }

        case ESPERANDO_DATO:
            if( InxAux < SIZE_STRING_DATO ){
                buf[InxAux] = dato;
                InxAux ++;
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                if( dato == CHAR_FINAL_DATO ){
                    return DATO_RECIBIDO;
                }
                else return MENSAJE_RECIBIDO_CORTADO;
            }

        default:
            Estado = ESPERANDO_INICIO;
            return RECIBI_BASURA;
            break;
    }
}
/********************************************************/
/********************************************************/
/********************************************************/
