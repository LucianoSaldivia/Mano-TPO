/*
 * CONDITIONAL_COMPILATION.h
 *
 *  Created on: Dec 16, 2018
 *      Author: Esteban Chiama
 */

#ifndef CONDITIONAL_COMPILATION_H_
#define CONDITIONAL_COMPILATION_H_

#define	MODO_COMPLETO_SIN_WIFI

#endif /* CONDITIONAL_COMPILATION_H_ */
