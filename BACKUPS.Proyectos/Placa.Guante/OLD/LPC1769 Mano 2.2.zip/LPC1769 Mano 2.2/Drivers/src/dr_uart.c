/*
 * dr_uart.c
 *
 *  Created on: Oct 14, 2018
 *      Author: cha
 */

#include "FW_UART.h"

// Flag de TX en curso
volatile uint8_t UART0_txEnCurso;

void UART0_Init (void) {

	// 1. Alimentar el periférico.
	PCONP |= ( (0x01)<<3 );

	// 2. Set-up clock del periférico.
	// Bits 6:7 == 0 => CCLK/4 = 25MHz.
	PCLKSEL0 &= ~(0x03 << 6);

	// 3. Configuración de trama. Largo de trama, paridad, bit de stop, etc.

		// Largo de trama.
		// Bits 0:1 == 11 => 8 bits
		U0LCR |= ( (0x3)<<0 );

		// Bits de stop
		// Bit 2 == 0 => 1 bit
		U0LCR &= ~( (0x1)<<2 );

		// Paridad
		// Bit 3 == 0 => desactivada
		U0LCR &= ~( (0x1)<<3 );

		// Break control
		// Bit 6 == 0 => desactivado
		U0LCR &= ~( (0x1)<<6 );

	// 4. Configuración del BaudRate. (hecho para 115200 baudios)

	/* Ecuación:
	** 									PCLK [Hz]
	** Baudrate =	----------------------------------------------------
	**				16 x (256 x DLM + DLL ) x ( 1 + DIVADDVAL / MULVAL )
	*/

	U0LCR |= ( (0x1)<<7 );		// DLAB == 1 para acceder a registros DLM y DLL
	U0DLM = 0;					// DLM == 0
	U0DLL = 0xC;				// DLL == 12

	*U0FDR = 0;
	*U0FDR |= ( (0xF)<<4 );    // Bits 4:7 . MULVAL == 15
	*U0FDR |= 0x02;	 		   // Bits 0:3 . DIVADDVAL == 2

	// 5. Configuración de pines para función de TX y RX
	SetPINSEL(P0, 2, PINSEL_FUNC1);		//TX1D : PIN ??	-> 	P0[2]
	SetPINSEL(P0, 3, PINSEL_FUNC1);		//RX1D : PIN ??	-> 	P0[3]

	// 6. Interrupciones

	U0LCR &= ~(0x01 << 7);		// DLAB == 0 para acceder a registros IER
	U0IER = 0x03;				// Habilito las interrupciones de RX y TX en la UART0
	ISER0 |= (1<<5);			// Habilito la interrupción de la UART0 en el NVIC

}

void UART0_IRQHandler ( void ) {
	uint8_t iir, dato;

	do {
		//Para limpiar los flags de IIR hay que leerlo, una vez que lo leí se resetea.
		iir = U0IIR;
		//THRE (Interrupción por TX)
		if (iir & 0x02) {
			if(!PopTx(&dato))
				U0THR = dato;	// hay un dato en el bufferTx para enviar
			else
				UART0_txEnCurso = 0; // si no hay más datos a enviar, limpio el flag
		}
		//Data Ready (Interrupción por RX)
		if ( iir & 0x04 ) {
			PushRx((uint8_t)U0RBR);	// guardo el dato recibido en el bufferRx
		}
	} while(!(iir & 0x01));	/* me fijo si cuando entré a la ISR había otra
						    int. pendiente de atención: b0=1 (ocurre únicamente
						    si dentro del mismo espacio temporal llegan dos
						    interrupciones a la vez) */
}

void UART0_StartTx(void)
{
	uint8_t dato;

	if(!PopTx(&dato))
		U0THR = dato;	//fuerzo la transmisión del primer dato
}
