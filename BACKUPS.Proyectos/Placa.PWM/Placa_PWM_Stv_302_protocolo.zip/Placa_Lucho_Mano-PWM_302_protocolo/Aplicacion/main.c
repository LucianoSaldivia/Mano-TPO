/*
===============================================================================
 Name        : Placa_Lucho_Mano-PWM_100.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include "DR_Init.h"

#include "PR_Teclas.h"
#include "PR_UART.h"

#include "AP_Mano.h"
#include "AP_UART_3.h"
#include "MDE_PC_Mano.h"
#include "MDE_Guante_Mano.h"

int main(void) {
	volatile uint8_t main_status = FREE;
	uint8_t U3_msg[20];
	uint8_t U2_msg[20];
	uint8_t U3_rx=0;

	Kit_Init();

    while(1) {

    	U0_RX_Mensajes();

//    	U2_rx = UART2_Recibir_ESP8266(U2_msg, 20);
//    	if( U2_rx == MENSAJE_RECIBIDO_COMPLETO ){
//
//    	}

    	U3_rx = UART3_Recibir_Dato_o_Comando( U3_msg );
    	if( U3_rx == COMANDO_RECIBIDO ){
    		U3_leer_comandos(U3_msg);
    	}
    	else if( U3_rx == DATO_RECIBIDO ){
    		leer_datos( U3_msg, U3 );
    	}

    	MDE_PC_Mano(&main_status);
    	MDE_Guante_Mano(&main_status);
    }

    return 0 ;
}
