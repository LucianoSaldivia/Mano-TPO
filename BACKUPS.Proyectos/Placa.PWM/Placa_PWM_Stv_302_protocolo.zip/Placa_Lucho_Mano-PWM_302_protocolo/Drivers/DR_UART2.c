/*******************************************************************************************************************************//**
 *
 * @file		DR_UART2.c
 * @brief		Breve descripción del objetivo del Módulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include "../inc/DR_UART2.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define U2_BORRAR_FLAG_RX
#define U2_BORRAR_FLAG_TX

#define U2_REGISTRO_RX		U2RBR
#define U2_REGISTRO_TX		U2THR
#define U2_LSR				U2LSR

#define PORT_PIN_U2_TX      P0,10
#define PORT_PIN_U2_RX      P0,11

#ifndef CONF_IR_UARTS
#define CONF_IR_UARTS
    #define MODEM               0
    #define TX                  1
    #define RX                  2
    #define ERRORES             3

    #define OE                  1
    #define PE                  2
    #define FE                  4
    #define BI                  8
#endif // CONF_IR_UARTS


/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

volatile uint8_t U2_Buf_RX[ U2_MAX_RX ];
volatile uint8_t U2_Buf_TX[ U2_MAX_TX ];

volatile uint8_t U2_Index_Out_Rx = 0 ;
volatile uint8_t U2_Index_In_Tx = 0;

volatile uint8_t U2_Index_In_Rx = 0;
volatile uint8_t U2_Index_Out_Tx = 0;

volatile uint8_t U2_TxEnCurso;   // Flag de TX en curso

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

void UART2_Init ( void ){
    //1.- Registro PCONP - bit 3 en 1 energiza la UART2
    PCONP |= (  0x01 << 24 );

    //2.- Registro PCLKSEL0 - bits 6 y 7 en 0 seleccionan que el clk de la UART2 sea 25MHz
    PCLKSEL0 &= ~( 0x03 << 16 );

    //3.- Set-up: Largo de trama,Paridad, Stop, etc.
    U2LCR |= ( 0x03 << 0 );             // Bit 0:1. Largo de trama. 11 es 8 bits
    U2LCR &= ~( 0x01 << 2 );            // Bit 2. Stop bits.        0 es 1 bit
    U2LCR &= ~( 0x01 << 3 );            // Bit 3. Parity enable.    0 es disabled
                                        // Bit 4:5 Parity Config.   ( está desabilitada )
    U2LCR &= ~( 0x01 << 6 );            // Bit 6. Break Control.    0 es disabled

    //4.- Configuración del BaudRate.

    /*
    * 		 	   MULVAL					   PCLK [Hz]
    * Baud = --------------------	X	--------------------------
    *		  MULVAL + DIVADDVAL		 16 x (256 x DLM + DLL )
    */

    // Setup para 115200 baudios

    // DLL y DLM
    U2LCR |= ( 0x01 << 7 );             // Bit 7. DLAB == 1 para acceder a registros DLM y DLL

    U2DLM &= ~( 0xFF << 0 );            // DLM Clear
    U2DLM |= ( 0 & 0xFF );              // DLM = 0

    U2DLL &= ~( 0xFF << 0 );            // DLL Clear
    U2DLL |= ( 10 & 0xFF );             // DLL = 10

    // MulVal y DivAddVal
    U2FDR &= ~( 0xFF << 0 );            // FDR Clear
    U2FDR |= ( ( 14 << 4 ) & 0xF0 );    // Bits 4:7 . MULVAL = 14
    U2FDR |= ( 5 & 0x0F );              // Bits 0:3 . DIVADDVAL = 5

    //5.- Desabilito la FIFO
    U2FCR &= ~( 0x01 );

    //6.- Habilito las funciones especiales de los pines TX y RX
    SetPINSEL( PORT_PIN_U2_TX, PINSEL_FUNC1 );
    SetPINSEL( PORT_PIN_U2_RX, PINSEL_FUNC1 );

    //7.- Registro LCR, pongo DLAB(bit7) en 0
    U2LCR &= ~( 0x01 << 7 );            // Bit 7. DLAB == 0 para acceder a registros THRE y RBR

    //8. Habilito las interrupciones de RX y TX en la UART2 (Registro U2IER)
    U2IER = 0x03;

    //9. Habilito la interrupción de la UART2 en el NVIC (Registro ISER0)
    ISER0 |= ( 0x01 << 7 );
}

void UART2_IRQHandler ( void ){

    uint8_t iir, Interrupcion; /* EN CASO DE HACER ANALISIS DE ERRORES DECLARAMOS AnalisisError; */

    do {
        iir = U2IIR;
        Interrupcion = (iir >> 1) & 3;

        // b2  b1
        //  0   0   Modem
        //  0   1   Tx
        //  1   0	Rx
        //  1   1   Error

        // THR EMPTY (Interrupción por TX)
        if ( Interrupcion == TX ) {
            U2_BORRAR_FLAG_TX;

            UART2_PopTx();
        }

        // Data Ready (Interrupción por RX)

        if ( Interrupcion == RX ) {
            U2_BORRAR_FLAG_RX;

            UART2_PushRx();	// Guardo el dato recibido en el BufferRx
        }

        /*  EN CASO DE HACER ANALISIS DE ERRORES
        if ( Interrupcion == ERRORES )
        {
            lsr = U2_LSR;
            AnalisisError = (lsr >> 1) & 0x0f;

            switch ( AnalisisError )
            {
                case OE:
                    // Avisar por OE
                    break;
                case PE:
                    // Avisar por PE
                    break;
                case FE:
                    // Avisar por FE
                    break;
                case BI:
                    // Avisar por BI
                    break;
            }
        }   */

    } while ( ! ( iir & 0x01 ) );	/* Me fijo si cuando entré a la ISR había otra
                                    int. pendiente de atención: b0=1 (ocurre únicamente
                                    si dentro del mismo espacio temporal llegan dos
                                    interrupciones a la vez) */
}


void UART2_StartTx( void ){
    if( U2_Index_In_Tx != U2_Index_Out_Tx ){
        U2_REGISTRO_TX = U2_Buf_TX[ U2_Index_Out_Tx ];	// Fuerzo la transmisión del primer dato
        U2_Index_Out_Tx ++;                             // Muevo el índice de salida de Tx
        U2_Index_Out_Tx %= U2_MAX_TX;
    }
}

void UART2_PopTx( void ){
    if( U2_Index_In_Tx != U2_Index_Out_Tx ){                // Si hay dato para transmitir
        U2_REGISTRO_TX = U2_Buf_TX[ U2_Index_Out_Tx ];    // Transmito el dato
        U2_Index_Out_Tx ++;                             // Muevo el índice de salida de Tx
        U2_Index_Out_Tx %= U2_MAX_TX;
    }
    else{                                           // Si no hay más datos a enviar, terminó
        U2_TxEnCurso = 0;                           // la transmisión, entonces limpio el flag
    }
}

void UART2_PushRx( void ){
    U2_Buf_RX[ U2_Index_In_Rx ] = U2_REGISTRO_RX;
    U2_Index_In_Rx ++;
    U2_Index_In_Rx %= U2_MAX_RX;
}

