/*******************************************************************************************************************************//**
 *
 * @file		DR_UART3.h
 * @brief		Breve descripción del objetivo del Módulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MODULO
 **********************************************************************************************************************************/

#ifndef DR_UART3_H_
#define DR_UART3_H_

/***********************************************************************************************************************************
 *** INCLUDES GLOBALES
 **********************************************************************************************************************************/

#include "DR_Tipos.h"
#include "DR_PINSEL.h"

/***********************************************************************************************************************************
 *** DEFINES GLOBALES
 **********************************************************************************************************************************/

//#ifndef		_REGISTROS_PCONP_
//#define		_REGISTROS_PCONP_
//    #define 	PCONP	(* ( ( registro_t  * ) 0x400FC0C4UL ))
//#endif	//	_REGISTROS_PCONP_
//
//#ifndef		_REGISTROS_PCLKSEL_
//#define		_REGISTROS_PCLKSEL_
//    #define		PCLKSEL		( ( registro_t  * ) 0x400FC1A8UL )
//
//    //!< Registros PCLKSEL
//    #define		PCLKSEL0	PCLKSEL[0]
//    #define		PCLKSEL1	PCLKSEL[1]
//#endif	//	_REGISTROS_PCLKSEL_

//#ifndef		_REGISTROS_NVIC_
//#define		_REGISTROS_NVIC_
//    //!< 0xE000E100UL : Direccion de inicio de los registros de habilitación (set) de interrupciones en el NVIC:
//    #define		ISER		( ( registro_t  * ) 0xE000E100UL )
//    //!< 0xE000E180UL : Direccion de inicio de los registros de deshabilitacion (clear) de interrupciones en el NVIC:
//    #define		ICER		( ( registro_t  * ) 0xE000E180UL )
//
//    //!< Registros ISER:
//    #define		ISER0		ISER[0]
//    #define		ISER1		ISER[1]
//
//    //!< Registros ICER:
//    #define		ICER0		ICER[0]
//    #define		ICER1		ICER[1]
//
//    //!<  Specific Interrupt Numbers:
//    #define  	TIMER0_IRQn		1       // Timer0 Interrupt
//    #define  	TIMER1_IRQn		2       // Timer1 Interrupt
//    #define  	TIMER2_IRQn		3       // Timer2 Interrupt
//    #define  	TIMER3_IRQn		4       // Timer3 Interrupt
//    #define  	UART0_IRQn		5       // UART0 Interrupt
//    #define  	UART1_IRQn		6       // UART1 Interrupt
//    #define  	UART2_IRQn		7       // UART2 Interrupt
//    #define  	UART3_IRQn		8       // UART3 Interrupt
//    #define     PWM1_IRQn       9       // PWM1 Interrupt
//    #define  	RTC_IRQn		17      // Real Time Clock Interrupt
//    #define  	EINT0_IRQn		18      // External Interrupt 0 Interrupt
//    #define  	EINT1_IRQn		19      // External Interrupt 1 Interrupt
//    #define  	EINT2_IRQn		20      // External Interrupt 2 Interrupt
//    #define  	EINT3_IRQn		21      // External Interrupt 3 Interrupt
//    #define  	ADC_IRQn		22      // A/D Converter Interrupt
//#endif	//	_REGISTROS_NVIC_

#define U3_MAX_RX                   512
#define U3_MAX_TX                   512

//!< 0x4009 C000 UL : Registro de control de la UART3:
#define		R_UART3	( ( registro  * ) 0x4009C000UL )

//!< Registros de la UART3:
#define		U3THR		R_UART3[0]
#define		U3RBR		R_UART3[0]
#define		U3DLL		R_UART3[0]

#define		U3DLM		R_UART3[1]
#define		U3IER		R_UART3[1]

#define		U3IIR		((__R uint32_t *)R_UART3)[2]
#define		U3FCR		((__W uint32_t *)R_UART3)[2]

#define		U3LCR		R_UART3[3]
//!< posición 4 no definida [consultar pag. 300 user manual LPC1769]
#define		U3LSR		R_UART3[5]
//!< posición 6 no definida [consultar pag. 300 user manual LPC1769]
#define		U3SCR		R_UART3[7]

#define		U3FDR		R_UART3[10]

#ifndef BITS_DE_ANALISIS_UARTS
#define BITS_DE_ANALISIS_UARTS

    #define 	IER_RBR		0x01
    #define 	IER_THRE	0x02
    #define 	IER_RLS		0x04

    #define 	IIR_PEND	0x01
    #define 	IIR_RLS		0x06
    #define 	IIR_RDA		0x04
    #define 	IIR_CTI		0x0C
    #define 	IIR_THRE	0x02

    #define 	LSR_RDR		0x01
    #define 	LSR_OE		0x02
    #define 	LSR_PE		0x04
    #define 	LSR_FE		0x08
    #define 	LSR_BI		0x10
    #define 	LSR_THRE	0x20
    #define 	LSR_TEMT	0x40
    #define 	LSR_RXFE	0x80

    #define		U0RDR		(U0LSR & LSR_RDR)
    #define		U0THRE		((U0LSR & LSR_THRE) >> 5)
    #define		U1RDR		(U1LSR & LSR_RDR)
    #define		U1THRE		((U1LSR & LSR_THRE) >> 5)
    #define		U2RDR		(U2LSR & LSR_RDR)
    #define		U2THRE		((U2LSR & LSR_THRE) >> 5)
    #define		U3RDR		(U3LSR & LSR_RDR)
    #define		U3THRE		((U3LSR & LSR_THRE) >> 5)

#endif  // BITS_DE_ANALISIS_UARTS

#ifndef CONF_UARTS_
#define CONF_UARTS_

#define PCLK_CCLK_1                 0
#define PCLK_CCLK_2                 1
#define PCLK_CCLK_4                 2
#define PCLK_CCLK_8                 3

#define BAUD_RATE_600               0
#define BAUD_RATE_1200              1
#define BAUD_RATE_2400              2
#define BAUD_RATE_4800              3
#define BAUD_RATE_9600              4
#define BAUD_RATE_14400             5
#define BAUD_RATE_19200             6
#define BAUD_RATE_28800             7
#define BAUD_RATE_38400             8
#define BAUD_RATE_56000             9
#define BAUD_RATE_57600             10
#define BAUD_RATE_115200            11
#define BAUD_RATE_128000            12
#define BAUD_RATE_230400            13
#define BAUD_RATE_256000            14

#define DATA_BITS_5         		5
#define DATA_BITS_6         		6
#define DATA_BITS_7         		7
#define DATA_BITS_8         		8

#define PARITY_NONE         		0
#define PARITY_ODD          		1
#define PARITY_EVEN         		2
#define PARITY_FORCE_1      		3
#define PARITY_FORCE_0      		4

#define STOP_BITS_1         		1
#define STOP_BITS_2         		2

#endif // CONF_UARTS_

/***********************************************************************************************************************************
 *** MACROS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES
 **********************************************************************************************************************************/

extern volatile uint8_t U3_Buf_RX[U3_MAX_RX];
extern volatile uint8_t U3_Buf_TX[U3_MAX_TX];

extern volatile uint8_t U3_Index_Out_Rx;
extern volatile uint8_t U3_Index_In_Tx;

extern volatile uint8_t U3_Index_In_Rx;
extern volatile uint8_t U3_Index_Out_Tx;

extern volatile uint8_t U3_TxEnCurso;

/***********************************************************************************************************************************
 *** PROTOTIPOS DE FUNCIONES GLOBALES
 **********************************************************************************************************************************/

void UART3_Init( void );

void UART3_StartTx( void );
void UART3_PopTx( void );
void UART3_PushRx( void );

#endif /* DR_UART3_H_ */

