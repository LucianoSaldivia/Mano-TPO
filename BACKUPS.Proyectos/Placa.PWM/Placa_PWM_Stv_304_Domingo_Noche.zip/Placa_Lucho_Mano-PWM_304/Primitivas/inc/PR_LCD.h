/*
 * PR_LCD.h
 *
 *  Created on:
 *      Author:
 */

#ifndef PR_LCD_H_
#define PR_LCD_H_

#include "Regs_LPC176x.h"
#include "FW_LCD.h"

void LCD_DisplayMsg(char * msg, uint8_t r, uint8_t pos);

#endif /* PR_LCD_H_ */
