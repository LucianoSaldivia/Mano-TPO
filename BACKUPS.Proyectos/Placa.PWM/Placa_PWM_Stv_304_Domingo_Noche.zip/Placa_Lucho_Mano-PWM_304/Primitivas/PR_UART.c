/*******************************************************************************************************************************//**
 *
 * @file		PR_UART.c
 * @brief		Descripcion del modulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include <string.h>
#include <stdio.h>
#include "../inc/PR_UART.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define ESPERANDO_INICIO        0
#define ESPERANDO_SIGUIENTE     1
#define ESPERANDO_COMANDO       2
#define ESPERANDO_DATO          3
#define LLEGO_CR                4

#define CHAR_INICIAL_COMANDO    '$'
#define CHAR_INICIAL_DATO       '%'
#define CHAR_FINAL				'#'
// protocolo antiguo
//#define CHAR_FINAL_COMANDO      '#'
//#define CHAR_FINAL_DATO         '$'

#define SIZE_STRING_DATO		14
#define SIZE_STRING_COMANDO		4


#define CANT_COMANDOS           10

#define SIZE_OF_MENSAJE         512

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

volatile const char *Tabla_Comandos_ESP8266[ CANT_COMANDOS ];

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

volatile static uint8_t ESP8266_Inicializado = 0;
volatile static uint8_t Estado_Conexion_WIFI = AUN_NO_INICIALIZADO;

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

/*  FUNCIONES PARA UART2    */

//!< Funcion para escribir un byte a UART2
void UART2_PushTx( int8_t dato ){

    U2_Buf_TX[ U2_Index_In_Tx ] = dato;
    U2_Index_In_Tx ++;
    U2_Index_In_Tx %= U2_MAX_TX;

    if (U2_TxEnCurso == 0) {    // Si no había una TX en curso
        U2_TxEnCurso = 1;       // pongo una TX en curso y
        UART2_StartTx();        // fuerzo el inicio de la TX
    }
}

//!< Funcion para leer un byte desde UART2
int8_t UART2_PopRx( void ){

    int8_t dato = BUFFER_VACIO;

    if ( U2_Index_In_Rx != U2_Index_Out_Rx ){
        dato = U2_Buf_RX[ U2_Index_Out_Rx ];
        U2_Index_Out_Rx ++;
        U2_Index_Out_Rx %= U2_MAX_RX;
    }
    return dato;
}

//!< Funcion para Transmitir datos en crudo por UART2
int8_t UART2_Transmitir( const void *Mensaje, uint16_t Size ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( Size >= U2_MAX_TX ){
        return BUFFER_OVERSIZE;
    }

    for( InxAux = 0; InxAux < Size; InxAux++ ){
        UART2_PushTx( mensaje[ InxAux ] );
    }

    return ENVIADO;
}

//!< Funcion para Transmitir un string UART_2
int8_t UART2_Transmitir_String( int8_t *mensaje ){

    uint32_t InxAux;

    if( mensaje[0] == '\0' ){
        return BUFFER_VACIO;
    }

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){
        UART2_PushTx( mensaje[ InxAux ] );
    }
    UART2_PushTx( '\0' );

    return ENVIADO;
}

//!< Funcion para recibir un string desde UART2
int8_t UART2_Recibir_String( int8_t *Mensaje, uint32_t Cant_Max ){

    static uint32_t InxAux = 0;
    int8_t dato;

    dato = UART2_PopRx();

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    if( dato != '\0' ){
        if( InxAux != Cant_Max - 1 ){
            Mensaje[InxAux] = dato;
            InxAux ++;
            return RECIBIENDO_MENSAJE;
        }
        else{
            Mensaje[InxAux] = '\0';
            InxAux = 0;
            return MENSAJE_RECIBIDO_CORTADO;
        }
    }
    else{
        Mensaje[InxAux] = '\0';
        InxAux = 0;
        return MENSAJE_RECIBIDO_COMPLETO;
    }
}

//!< Funcion para Transmitir un mensaje como Char_Inicial + Mensaje + Char_Final por UART2
int8_t UART2_Transmitir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( mensaje[0] == '\0' ){    // Si el mensaje está vacío
        return BUFFER_VACIO;
    }

    if( strlen( mensaje ) > U2_MAX_TX - 2 ){   // Si mensaje es mas largo que UN_MAX_TX
        return BUFFER_OVERSIZE;
    }

    UART2_PushTx( Char_Inicial );   // Transmito Char_Inicial

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){    // Transmito Mensaje
        UART2_PushTx( mensaje[ InxAux ] );
    }

    UART2_PushTx( Char_Final );     // Transmito Char_Final

    return ENVIADO;
}

//!< Funcion (Máquina de estados) para recibir un mensaje desde Char_Inicial hasta Char_Final desde UART2
int8_t UART2_Recibir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final ){

    static uint8_t Estado = ESPERANDO_INICIO;
    static uint32_t InxAux = 0;
    int8_t *buf = (int8_t *) Mensaje;
    int8_t dato;

    dato = UART2_PopRx( );

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == Char_Inicial ){
                Estado = ESPERANDO_SIGUIENTE;
                return RECIBIENDO_MENSAJE;
            }
            else return RECIBI_BASURA;
            break;

        case ESPERANDO_SIGUIENTE:
            if( dato != Char_Final ){
                if( InxAux != MAX_TRAMA_RECIBIDA - 1 ){
                    buf[InxAux] = dato;
                    InxAux ++;
                    return RECIBIENDO_MENSAJE;
                }
                else{
                    buf[InxAux] = '\0';
                    Estado = ESPERANDO_INICIO;
                    InxAux = 0;
                    return MENSAJE_RECIBIDO_CORTADO;
                }
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                return MENSAJE_RECIBIDO_COMPLETO;
            }
            break;

        default:
            Estado = ESPERANDO_INICIO;
            return RECIBI_BASURA;
            break;
    }
}

//!< Funcion (Máquina de estados) para recibir un Dato o un Comando de ancho fijo por UART2
int8_t UART2_Recibir_Dato_o_Comando( const void *Mensaje ){
    static uint8_t Estado = ESPERANDO_INICIO;
    static uint16_t InxAux = 0;
    int8_t *buf;
    int8_t dato;

    dato = UART2_PopRx();

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    buf = ( int8_t * ) Mensaje;

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == CHAR_INICIAL_COMANDO ){
                Estado = ESPERANDO_COMANDO;
                return RECIBIENDO_MENSAJE;
            }
            else if( dato == CHAR_INICIAL_DATO ){
                Estado = ESPERANDO_DATO;
                return RECIBIENDO_MENSAJE;
            }
            else return RECIBI_BASURA;
            break;

        case ESPERANDO_COMANDO:
            if( InxAux < SIZE_STRING_COMANDO ){
                buf[InxAux] = dato;
                InxAux ++;
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                if( dato == CHAR_FINAL ){
                    return COMANDO_RECIBIDO;
                }
                else return MENSAJE_RECIBIDO_CORTADO;
            }

        case ESPERANDO_DATO:
            if( InxAux < SIZE_STRING_DATO ){
                buf[InxAux] = dato;
                InxAux ++;
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                if( dato == CHAR_FINAL ){
                    return DATO_RECIBIDO;
                }
                else return MENSAJE_RECIBIDO_CORTADO;
            }

        default:
            Estado = ESPERANDO_INICIO;
            return RECIBI_BASURA;
            break;
    }
}


//!< Funcion para Transmitir un Comando como "Comando" + '\r' + '\n'
int8_t UART2_Transmitir_ESP8266( const void *Mensaje ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( mensaje[0] == '\0' ){    // Si el mensaje está vacío
        return BUFFER_VACIO;
    }

    if( strlen( mensaje ) >= U2_MAX_TX ){   // Si mensaje es mas largo que UN_MAX_TX
        return BUFFER_OVERSIZE;
    }

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){    // Transmito Mensaje
        UART2_PushTx( mensaje[ InxAux ] );
    }

    UART2_PushTx( '\r' );     // Transmito el final del mensaje para el ESP8266
    UART2_PushTx( '\n' );


    return ENVIADO;
}

//!< Funcion para recibir un string del ESP8266 ( terminado en '\r' + '\n' ) desde UART2
int8_t UART2_Recibir_ESP8266( const void *Mensaje, uint16_t Cant_Max ){

    static uint8_t Estado = ESPERANDO_INICIO;
    static uint32_t InxAux = 0;
    int8_t *buf = (int8_t *) Mensaje;
    int8_t dato;

    dato = UART2_PopRx( );

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == BUFFER_VACIO ){
                return BUFFER_VACIO;
            }
            else{
                buf[ InxAux ] = dato;
                InxAux ++;
                Estado = ESPERANDO_SIGUIENTE;
                return RECIBIENDO_MENSAJE;
            }
            break;

        case ESPERANDO_SIGUIENTE:
            if( InxAux != MAX_TRAMA_RECIBIDA - 1 ){
                buf[ InxAux ] = dato;
                InxAux ++;
                if( dato == '\r' ){
                    Estado = LLEGO_CR;
                }
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[ InxAux ] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                return MENSAJE_RECIBIDO_CORTADO;
            }

        case LLEGO_CR:
            if( dato == '\n' ){
                buf[ InxAux - 1 ] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                return MENSAJE_RECIBIDO_COMPLETO;
            }
            else{
                if( InxAux != MAX_TRAMA_RECIBIDA - 1 ){
                    buf[ InxAux ] = dato;
                    Estado = ESPERANDO_SIGUIENTE;
                    InxAux ++;
                    return RECIBIENDO_MENSAJE;
                }
                else{
                    buf[ InxAux ] = '\0';
                    Estado = ESPERANDO_INICIO;
                    InxAux = 0;
                    return MENSAJE_RECIBIDO_CORTADO;
                }
            }
            break;

        default:
            Estado = ESPERANDO_INICIO;
            return BUFFER_VACIO;
            break;
    }
}

//!< Funcion para realizar la Inicializacion del módulo ESP8266
int8_t UART2_Inicializar_ESP8266( void ){
    int8_t Mensaje[ SIZE_OF_MENSAJE ];
    static uint8_t Trama_Actual_Enviada = 0;
    static uint8_t Estado_Inicializacion = _AT_;

    /* Descripción:
     *      Inicializa el módulo ESP8266.
     *          "AT"
     *          "AT+UART_DEF=115200,8,1,0,0"
     *          "AT+RST"
     *          "AT+CWAUTOCONN=0"
     *          "AT+CWMODE_DEF=1"
     */

    switch( Estado_Conexion_WIFI ) {
        case _AT_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Inicializacion = _AT_UART_DEF_;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _AT_UART_DEF_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT+UART_DEF=115200,8,1,0,0" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Inicializacion = _AT_RST_;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _AT_RST_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT+RST" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Inicializacion = _AT_CWAUTOCONN_;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _AT_CWAUTOCONN_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT+CWAUTOCONN=0" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Inicializacion = _AT_CWMODE_DEF_;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _AT_CWMODE_DEF_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT+CWMODE_DEF=1" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Inicializacion = _ESP8266_INICIALIZADO_;
                    ESP8266_Inicializado = 1;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _ESP8266_INICIALIZADO_:
            break;
    }
    return Estado_Inicializacion;
}

//!< Funcion para realizar la conexion del ESP8266 por WIFI a un server TCP
int8_t UART2_Conectar_ESP8266( void ){
    int8_t Mensaje[ SIZE_OF_MENSAJE ];
    static uint8_t Trama_Actual_Enviada = 0;
    int8_t Aux_Str[ SIZE_OF_MENSAJE ];

    switch( Estado_Conexion_WIFI ) {
        case AUN_NO_INICIALIZADO:
            if( ! ESP8266_Inicializado ) {
                UART2_Inicializar_ESP8266();
            }
            else{
                Estado_Conexion_WIFI = _AT_;
            }
            break;

        case _AT_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Conexion_WIFI = _AT_CWLAPOPT_;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _AT_CWLAPOPT_:
            if( Trama_Actual_Enviada == 0 ){
                UART2_Transmitir_ESP8266( "AT+CWLAPOPT=1,127" );
                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Conexion_WIFI = _AT_CWLAP_;
                    Trama_Actual_Enviada = 0;
                }
            }
            break;

        case _AT_CWLAP_:
            if( Trama_Actual_Enviada == 0 ){
                strcpy( Aux_Str, "AT+CWLAP=" );
                strcat( Aux_Str, "\"" );
                strcat( Aux_Str, _NOMBRE_RED_WIFI_SSID_ );
                strcat( Aux_Str, "\"" );

                UART2_Transmitir_ESP8266( Aux_Str );

                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Conexion_WIFI = _AT_CWJAP_CUR_;
                    Trama_Actual_Enviada = 0;
                }
                else{
                    Estado_Conexion_WIFI = _ESP8266_WIFI_SSID_ERROR_;
                }
            }
            break;

        case _AT_CWJAP_CUR_:
            if( Trama_Actual_Enviada == 0 ){
                strcpy( Aux_Str, "AT+CWJAP_CUR=" );
                strcat( Aux_Str, "\"" );
                strcat( Aux_Str, _NOMBRE_RED_WIFI_SSID_ );
                strcat( Aux_Str, "\",\"" );
                strcat( Aux_Str, _PASSWORD_RED_WIFI_ );
                strcat( Aux_Str, "\"" );

                UART2_Transmitir_ESP8266( Aux_Str );

                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL ){
                    Estado_Conexion_WIFI = _AT_CIPSTART_;
                    Trama_Actual_Enviada = 0;
                }
                else{
                    Estado_Conexion_WIFI = _ESP8266_WIFI_PASSWORD_ERROR_;
                }
            }
            break;

        case _AT_CIPSTART_:
            if( Trama_Actual_Enviada == 0 ){
                strcpy( Aux_Str, "AT+CIPSTART=\"TCP\"," );
                strcat( Aux_Str, "\"" );
                strcat( Aux_Str, _IP_NUMBER_ );
                strcat( Aux_Str, "\"," );
                strcat( Aux_Str, _PORT_NUMBER_ );

                UART2_Transmitir_ESP8266( Aux_Str );

                Trama_Actual_Enviada = 1;
            }
            if( UART2_Recibir_ESP8266( Mensaje, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
                if( strstr( Mensaje, "OK" ) != NULL || strstr( Mensaje, "ALREADY" ) != NULL  ){
                    return _ESP8266_CONECTADO_;
                }
                else if( strstr( Mensaje, "ERROR" ) != NULL ){
                    Estado_Conexion_WIFI = _ESP8266_SOCKET_ERROR_;
                }
            }
            break;

        case _ESP8266_CONECTADO_:
        case _ESP8266_WIFI_SSID_ERROR_:
        case _ESP8266_WIFI_PASSWORD_ERROR_:
        case _ESP8266_SOCKET_ERROR_:
            break;
    }
    return Estado_Conexion_WIFI;
}

//!< Funcion para enviar datos por WiFi, a traves del módulo ESP8266
int8_t UART2_ESP8266_Enviar( const void *Mensaje, uint16_t Cant_Max ){
    int8_t Mensaje_Recibido[ SIZE_OF_MENSAJE ];
    int8_t Aux_Str[ SIZE_OF_MENSAJE ], Aux_Str_2[ SIZE_OF_MENSAJE ];
    int8_t *mensaje = (int8_t*) Mensaje;

    strcpy( Aux_Str, "AT+CIPSEND=" );
    sprintf( Aux_Str_2, "%d", Cant_Max );
    strcat( Aux_Str, Aux_Str_2 );

    if( UART2_Recibir_ESP8266( Mensaje_Recibido, SIZE_OF_MENSAJE ) == MENSAJE_RECIBIDO_COMPLETO ){
        if( strstr( Mensaje_Recibido, "OK" ) != NULL ){
            UART2_Transmitir_ESP8266( mensaje );
        }
    }
    return 0;
}



/*  FUNCIONES PARA UART3    */

//!< Funcion para escribir un byte a UART3
void UART3_PushTx( int8_t dato ){

    U3_Buf_TX[ U3_Index_In_Tx ] = dato;
    U3_Index_In_Tx ++;
    U3_Index_In_Tx %= U3_MAX_TX;

    if (U3_TxEnCurso == 0) {    // Si no había una TX en curso
        U3_TxEnCurso = 1;       // pongo una TX en curso y
        UART3_StartTx();        // fuerzo el inicio de la TX
    }
}

//!< Funcion para leer un byte desde UART3
int8_t UART3_PopRx( void ){

    int8_t dato = BUFFER_VACIO;

    if ( U3_Index_In_Rx != U3_Index_Out_Rx ){
        dato = U3_Buf_RX[ U3_Index_Out_Rx ];
        U3_Index_Out_Rx ++;
        U3_Index_Out_Rx %= U3_MAX_RX;
    }
    return dato;
}

//!< Funcion para Transmitir datos en crudo por UART3
int8_t UART3_Transmitir( const void *Mensaje, uint16_t Size ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( Size >= U3_MAX_TX ){
        return BUFFER_OVERSIZE;
    }

    for( InxAux = 0; InxAux < Size; InxAux++){
        UART3_PushTx( mensaje[ InxAux ] );
    }

    return ENVIADO;
}

//!< Funcion para Transmitir un string UART_3
int8_t UART3_Transmitir_String( int8_t *mensaje ){

    uint32_t InxAux;

    if( mensaje[0] == '\0' ){
        return BUFFER_VACIO;
    }

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){
        UART3_PushTx( mensaje[ InxAux ] );
    }
    UART3_PushTx( '\0' );

    return ENVIADO;
}

//!< Funcion para recibir un string desde UART3
int8_t UART3_Recibir_String( int8_t *Mensaje, uint32_t Cant_Max ){

    static uint32_t InxAux = 0;
    int8_t dato;

    dato = UART3_PopRx();

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    if( dato != '\0' ){
        if( InxAux != Cant_Max - 1 ){
            Mensaje[InxAux] = dato;
            InxAux ++;
            return RECIBIENDO_MENSAJE;
        }
        else{
            Mensaje[InxAux] = '\0';
            InxAux = 0;
            return MENSAJE_RECIBIDO_CORTADO;
        }
    }
    else{
        Mensaje[InxAux] = '\0';
        InxAux = 0;
        return MENSAJE_RECIBIDO_COMPLETO;
    }
}

//!< Funcion para Transmitir un mensaje como Char_Inicial + Mensaje + Char_Final por UART3
int8_t UART3_Transmitir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final ){

    int8_t *mensaje = (int8_t *) Mensaje;
    uint32_t InxAux = 0;

    if( mensaje[0] == '\0' ){    // Si el mensaje está vacío
        return BUFFER_VACIO;
    }

    if( strlen( mensaje ) > U3_MAX_TX - 2 ){   // Si mensaje es mas largo que UN_MAX_TX
        return BUFFER_OVERSIZE;
    }

    UART3_PushTx( Char_Inicial );   // Transmito Char_Inicial

    for( InxAux = 0; mensaje[ InxAux ] != '\0'; InxAux++){    // Transmito Mensaje
        UART3_PushTx( mensaje[ InxAux ] );
    }

    UART3_PushTx( Char_Final );     // Transmito Char_Final

    return ENVIADO;
}

//!< Funcion (Máquina de estados) para recibir un mensaje desde Char_Inicial hasta Char_Final desde UART3
int8_t UART3_Recibir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final ){

    static uint8_t Estado = ESPERANDO_INICIO;
    static uint32_t InxAux = 0;
    int8_t *buf = (int8_t *) Mensaje;
    int8_t dato;


    dato = UART3_PopRx( );

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == Char_Inicial ){
                Estado = ESPERANDO_SIGUIENTE;
                return RECIBIENDO_MENSAJE;
            }
            else return RECIBI_BASURA;
            break;

        case ESPERANDO_SIGUIENTE:
            if( dato != Char_Final ){
                if( InxAux != MAX_TRAMA_RECIBIDA - 1 ){
                    buf[InxAux] = dato;
                    InxAux ++;
                    return RECIBIENDO_MENSAJE;
                }
                else{
                    buf[InxAux] = '\0';
                    Estado = ESPERANDO_INICIO;
                    InxAux = 0;
                    return MENSAJE_RECIBIDO_CORTADO;
                }
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                return MENSAJE_RECIBIDO_COMPLETO;
            }
            break;

        default:
            Estado = ESPERANDO_INICIO;
            return RECIBI_BASURA;
            break;
    }
}

//!< Funcion (Máquina de estados) para recibir un Dato o un Comando de ancho fijo por UART3
int8_t UART3_Recibir_Dato_o_Comando( const void *Mensaje ){
    static uint8_t Estado = ESPERANDO_INICIO;
    static uint16_t InxAux = 0;
    int8_t *buf;
    int8_t dato;

    dato = UART3_PopRx();

    if( dato == BUFFER_VACIO ){
        return BUFFER_VACIO;
    }

    buf = ( int8_t * ) Mensaje;

    switch( Estado ){
        case ESPERANDO_INICIO:
            if( dato == CHAR_INICIAL_COMANDO ){
                Estado = ESPERANDO_COMANDO;
                return RECIBIENDO_MENSAJE;
            }
            else if( dato == CHAR_INICIAL_DATO ){
                Estado = ESPERANDO_DATO;
                return RECIBIENDO_MENSAJE;
            }
            else return RECIBI_BASURA;
            break;

        case ESPERANDO_COMANDO:
            if( InxAux < SIZE_STRING_COMANDO ){
                buf[InxAux] = dato;
                InxAux ++;
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                if( dato == CHAR_FINAL ){
                    return COMANDO_RECIBIDO;
                }
                else return MENSAJE_RECIBIDO_CORTADO;
            }

        case ESPERANDO_DATO:
            if( InxAux < SIZE_STRING_DATO ){
                buf[InxAux] = dato;
                InxAux ++;
                return RECIBIENDO_MENSAJE;
            }
            else{
                buf[InxAux] = '\0';
                Estado = ESPERANDO_INICIO;
                InxAux = 0;
                if( dato == CHAR_FINAL ){
                    return DATO_RECIBIDO;
                }
                else return MENSAJE_RECIBIDO_CORTADO;
            }

        default:
            Estado = ESPERANDO_INICIO;
            return RECIBI_BASURA;
            break;
    }
}
/********************************************************/
/********************************************************/
/********************************************************/
