/*******************************************************************************************************************************//**
 *
 * @file		AP_Mano.c.c
 * @brief		--Descripción del Módulo--
 * @date		1:45:07 PM
 * @author		Esteban Chiama
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/
#include "AP_Mano.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

volatile uint8_t command = NO_COMMAND;

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

void UART0_EnviarMano(Mano_t Mano) {

		U0_PushTx('%');

		U0_PushTx( (uint8_t) ((Mano.Menique >> 8) & 0xF) );		// Envío los 8 bits (en realidad 4, el ADC es de 12bits) más significativos
		U0_PushTx( (uint8_t) (Mano.Menique & 0xFF) );			// Envío los 8 bits menos significativos

		U0_PushTx(',');

		U0_PushTx( (uint8_t) ((Mano.Anular >> 8) & 0xF) );
		U0_PushTx( (uint8_t) (Mano.Anular & 0xFF) );

		U0_PushTx(',');

		U0_PushTx( (uint8_t) ((Mano.Medio >> 8) & 0xF) );
		U0_PushTx( (uint8_t) (Mano.Medio & 0xFF) );

		U0_PushTx(',');

		U0_PushTx( (uint8_t) ((Mano.Indice >> 8) & 0xF) );
		U0_PushTx( (uint8_t) (Mano.Indice & 0xFF) );

		U0_PushTx(',');

		U0_PushTx( (uint8_t) ((Mano.Pulgar >> 8) & 0xF) );
		U0_PushTx( (uint8_t) (Mano.Pulgar & 0xFF) );

		U0_PushTx('#');
}

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

Lecturas_Mano_1000 Adaptar_Manos( Mano_t ManoUART){
	Lecturas_Mano_1000 Adaptada;

	Adaptada.Pulgar = ManoUART.Pulgar;
	Adaptada.Indice = ManoUART.Indice;
	Adaptada.Mayor = ManoUART.Medio;
	Adaptada.Anular = ManoUART.Anular;
	Adaptada.Menor = ManoUART.Menique;

	return Adaptada;
}

void leer_datos( const uint8_t trama_datos[], uint8_t UART_Select ){
	Mano_t aux;

	// Formato de los datos recibidos:		Menique , Anular, Medio, Indice, Pulgar
	// Cada dedo son 2 bytes
	// El primero siendo el más significativo

	if( (trama_datos[2] == ',') && (trama_datos[5] == ',') && (trama_datos[8] == ',') && (trama_datos[11] == ',') ){
		// DEBUG
		// envío por la UART0 lo recibido
//		U0_PushTx((uint8_t) '%');
//		U0_PushTx(trama_datos[0]);
//		U0_PushTx(trama_datos[1]);
//		U0_PushTx(trama_datos[2]);
//		U0_PushTx(trama_datos[3]);
//		U0_PushTx(trama_datos[4]);
//		U0_PushTx(trama_datos[5]);
//		U0_PushTx(trama_datos[6]);
//		U0_PushTx(trama_datos[7]);
//		U0_PushTx(trama_datos[8]);
//		U0_PushTx(trama_datos[9]);
//		U0_PushTx(trama_datos[10]);
//		U0_PushTx(trama_datos[11]);
//		U0_PushTx(trama_datos[12]);
//		U0_PushTx(trama_datos[13]);
//		U0_PushTx((uint8_t)'#');

		// recomponer uint16_t
		aux.Menique = ( trama_datos[0] << 8 );	// most significant byte
		aux.Menique |= trama_datos[1];			// less significant byte

		aux.Anular = ( trama_datos[3] << 8 );
		aux.Anular |= trama_datos[4];

		aux.Medio = ( trama_datos[6] << 8 );
		aux.Medio |= trama_datos[7];

		aux.Indice = ( trama_datos[9] << 8 );
		aux.Indice |= trama_datos[10];

		aux.Pulgar = ( trama_datos[12] << 8 );
		aux.Pulgar |= trama_datos[13];

		// Hay que dar vuelta los datos
		aux.Menique = 1000 - aux.Menique;
		aux.Anular = 1000 - aux.Anular;
		aux.Medio = 1000 - aux.Medio;
		aux.Indice = 1000 - aux.Indice;
		aux.Pulgar = 1000 - aux.Pulgar;

		if( UART_Select == U0 ){
			U0_Data_Adaptada = Adaptar_Manos(aux);
			f_U0_Data = DATA_AVAILABLE;
		}
		else if ( UART_Select == U3 ){
			U3_Data_Adaptada = Adaptar_Manos(aux);
			f_U3_Data = DATA_AVAILABLE;
		}
	}
}

