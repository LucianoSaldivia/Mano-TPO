/*******************************************************************************************************************************//**
 *
 * @file		DR_UART3.c
 * @brief		Breve descripción del objetivo del Módulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include "../inc/DR_UART3.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define U3_BORRAR_FLAG_RX
#define U3_BORRAR_FLAG_TX

#define U3_REGISTRO_RX		U3RBR
#define U3_REGISTRO_TX		U3THR
#define U3_LSR				U3LSR

#define PORT_PIN_U3_TX      P0,25
#define PORT_PIN_U3_RX      P0,26

#ifndef CONF_IR_UARTS
#define CONF_IR_UARTS
    #define MODEM               0
    #define TX                  1
    #define RX                  2
    #define ERRORES             3

    #define OE                  1
    #define PE                  2
    #define FE                  4
    #define BI                  8
#endif // CONF_IR_UARTS


/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

volatile uint8_t U3_Buf_RX[ U3_MAX_RX ];
volatile uint8_t U3_Buf_TX[ U3_MAX_TX ];

volatile uint8_t U3_Index_Out_Rx = 0 ;
volatile uint8_t U3_Index_In_Tx = 0;

volatile uint8_t U3_Index_In_Rx = 0;
volatile uint8_t U3_Index_Out_Tx = 0;

volatile uint8_t U3_TxEnCurso;   // Flag de TX en curso

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

void UART3_Init ( void ){
    //1.- Registro PCONP - bit 3 en 1 energiza la UART3
    PCONP |= (  0x01 << 25 );

    //2.- Registro PCLKSEL0 - bits 6 y 7 en 0 seleccionan que el clk de la UART3 sea 25MHz
    PCLKSEL0 &= ~( 0x03 << 18 );

    //3.- Set-up: Largo de trama,Paridad, Stop, etc.
    U3LCR |= ( 0x03 << 0 );             // Bit 0:1. Largo de trama. 11 es 8 bits
    U3LCR &= ~( 0x01 << 2 );            // Bit 2. Stop bits.        0 es 1 bit
    U3LCR &= ~( 0x01 << 3 );            // Bit 3. Parity enable.    0 es disabled
                                        // Bit 4:5 Parity Config.   ( está desabilitada )
    U3LCR &= ~( 0x01 << 6 );            // Bit 6. Break Control.    0 es disabled

    //4.- Configuración del BaudRate.

    /*
    * 		 	   MULVAL					   PCLK [Hz]
    * Baud = --------------------	X	--------------------------
    *		  MULVAL + DIVADDVAL		 16 x (256 x DLM + DLL )
    */

    // Setup para 115200 baudios

    // DLL y DLM
    U3LCR |= ( 0x01 << 7 );             // Bit 7. DLAB == 1 para acceder a registros DLM y DLL

    U3DLM &= ~( 0xFF << 0 );            // DLM Clear
    U3DLM |= ( 0 & 0xFF );              // DLM = 0

    U3DLL &= ~( 0xFF << 0 );            // DLL Clear
    U3DLL |= ( 10 & 0xFF );             // DLL = 10

    // MulVal y DivAddVal
    U3FDR &= ~( 0xFF << 0 );            // FDR Clear
    U3FDR |= ( ( 14 << 4 ) & 0xF0 );    // Bits 4:7 . MULVAL = 14
    U3FDR |= ( 5 & 0x0F );              // Bits 0:3 . DIVADDVAL = 5

    //5.- Desabilito la FIFO
    U3FCR &= ~( 0x01 );

    //6.- Habilito las funciones especiales de los pines TX y RX
    SetPINSEL( PORT_PIN_U3_TX, PINSEL_FUNC3 );
    SetPINSEL( PORT_PIN_U3_RX, PINSEL_FUNC3 );

    //7.- Registro LCR, pongo DLAB(bit7) en 0
    U3LCR &= ~( 0x01 << 7 );            // Bit 7. DLAB == 0 para acceder a registros THRE y RBR

    //8. Habilito las interrupciones de RX y TX en la UART3 (Registro U3IER)
    U3IER = 0x03;

    //9. Habilito la interrupción de la UART3 en el NVIC (Registro ISER0)
    ISER0 |= ( 0x01 << 8 );
}

void UART3_IRQHandler ( void ){

    uint8_t iir, Interrupcion; /* EN CASO DE HACER ANALISIS DE ERRORES DECLARAMOS AnalisisError; */

    do {
        iir = U3IIR;
        Interrupcion = (iir >> 1) & 3;

        // b2  b1
        //  0   0   Modem
        //  0   1   Tx
        //  1   0	Rx
        //  1   1   Error

        // THR EMPTY (Interrupción por TX)
        if ( Interrupcion == TX ) {
            U3_BORRAR_FLAG_TX;

            UART3_PopTx();
        }

        // Data Ready (Interrupción por RX)

        if ( Interrupcion == RX ) {
            U3_BORRAR_FLAG_RX;

            UART3_PushRx();	// Guardo el dato recibido en el BufferRx
        }

        /*  EN CASO DE HACER ANALISIS DE ERRORES
        if ( Interrupcion == ERRORES )
        {
            lsr = U3_LSR;
            AnalisisError = (lsr >> 1) & 0x0f;

            switch ( AnalisisError )
            {
                case OE:
                    // Avisar por OE
                    break;
                case PE:
                    // Avisar por PE
                    break;
                case FE:
                    // Avisar por FE
                    break;
                case BI:
                    // Avisar por BI
                    break;
            }
        }   */

    } while ( ! ( iir & 0x01 ) );	/* Me fijo si cuando entré a la ISR había otra
                                    int. pendiente de atención: b0=1 (ocurre únicamente
                                    si dentro del mismo espacio temporal llegan dos
                                    interrupciones a la vez) */
}


void UART3_StartTx( void ){
    if( U3_Index_In_Tx != U3_Index_Out_Tx ){
        U3_REGISTRO_TX = U3_Buf_TX[ U3_Index_Out_Tx ];	// Fuerzo la transmisión del primer dato
        U3_Index_Out_Tx ++;                             // Muevo el índice de salida de Tx
        U3_Index_Out_Tx %= U3_MAX_TX;
    }
}

void UART3_PopTx( void ){
    if( U3_Index_In_Tx != U3_Index_Out_Tx ){                // Si hay dato para transmitir
        U3_REGISTRO_TX = U3_Buf_TX[ U3_Index_Out_Tx ];    // Transmito el dato
        U3_Index_Out_Tx ++;                             // Muevo el índice de salida de Tx
        U3_Index_Out_Tx %= U3_MAX_TX;
    }
    else{                                           // Si no hay más datos a enviar, terminó
        U3_TxEnCurso = 0;                           // la transmisión, entonces limpio el flag
    }
}

void UART3_PushRx( void ){
    U3_Buf_RX[ U3_Index_In_Rx ] = U3_REGISTRO_RX;
    U3_Index_In_Rx ++;
    U3_Index_In_Rx %= U3_MAX_RX;
}

