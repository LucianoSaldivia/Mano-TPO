/*******************************************************************************************************************************//**
 *
 * @file		PR_UART.h
 * @brief		Breve descripción del objetivo del Módulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MODULO
 **********************************************************************************************************************************/

#ifndef PR_UART_H_
#define PR_UART_H_

/***********************************************************************************************************************************
 *** INCLUDES GLOBALES
 **********************************************************************************************************************************/

#include "DR_UART2.h"
#include "DR_UART3.h"


/***********************************************************************************************************************************
 *** DEFINES GLOBALES
 **********************************************************************************************************************************/

#define _NOMBRE_RED_WIFI_SSID_          "Ron Damon"
#define _PASSWORD_RED_WIFI_             "yolevoyalnecaxaprofesor"
#define _IP_NUMBER_                     "193.0.1.5"
#define _PORT_NUMBER_                   "8000"



//#define UART0                           ( (uint8_t) 0 )
//    #define UART_0                          UART0
//#define UART1                           ( (uint8_t) 1 )
//    #define UART_1                          UART1
//#define UART2                           ( (uint8_t) 2 )
//    #define UART_2                          UART2
//#define UART3                           ( (uint8_t) 3 )
//    #define UART_3                          UART3

#define ENVIADO                         0
#define RECIBIENDO_MENSAJE              0
#define MENSAJE_RECIBIDO_CORTADO        1
#define MENSAJE_RECIBIDO_COMPLETO       2
#define COMANDO_RECIBIDO                3
#define DATO_RECIBIDO                   4

#define RECIBI_BASURA                   ( (int8_t) -1 )
#define BUFFER_VACIO                    ( (int8_t) -2 )
#define BUFFER_OVERSIZE                 ( (int8_t) -3 )
#define UART_INEXISTENTE                ( (int8_t) -4 )
#define RED_WIFI_NO_ENCONTRADA          ( (int8_t) -5 )
#define RED_WIFI_NO_CONECTADA           ( (int8_t) -6 )
#define SOCKET_ERROR                    ( (int8_t) -7 )

#define MAX_TRAMA_RECIBIDA              50

#define _AT_                            ( (int8_t) 0 )

#define _AT_RST_                        ( (int8_t) 1 )
#define _AT_CWAUTOCONN_                 ( (int8_t) 2 )
#define _AT_CWMODE_DEF_                 ( (int8_t) 3 )
#define _ESP8266_INICIALIZADO_          ( (int8_t) 4 )

#define _AT_UART_DEF_                   ( (int8_t) 5 )
#define _AT_CWLAPOPT_                   ( (int8_t) 6 )
#define _AT_CWLAP_                      ( (int8_t) 7 )
#define _AT_CWJAP_CUR_                  ( (int8_t) 8 )
#define _AT_CIPSTART_                   ( (int8_t) 9 )

#define _ESP8266_CONECTADO_             ( (int8_t) 10 )
#define _ESP8266_WIFI_SSID_ERROR_       ( (int8_t) 11 )
#define _ESP8266_WIFI_PASSWORD_ERROR_   ( (int8_t) 12 )
#define _ESP8266_SOCKET_ERROR_          ( (int8_t) 13 )
#define AUN_NO_INICIALIZADO             ( (int8_t) 14 )


#define WIFI_INICIO                     _AT_
#define WIFI_CONFIG                     _AT_UART_DEF_
#define WIFI_LISTAP                     _AT_CWLAPOPT_
#define WIFI_JOINAP                     _AT_CWJAP_CUR_
#define WIFI_TCP_START_                 _AT_CIPSTART_
#define WIFI_READY_TO_SEND_             ( (int8_t) 35 )



/***********************************************************************************************************************************
 *** MACROS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES
 **********************************************************************************************************************************/

extern volatile const char *Tabla_Comandos_ESP8266[];

/***********************************************************************************************************************************
 *** PROTOTIPOS DE FUNCIONES GLOBALES
 **********************************************************************************************************************************/

/*  FUNCIONES PARA UART2    */

void UART2_PushTx( int8_t dato );
    /* Descripción:
     *      Pasa Dato al buffer de transmisión, desde el cual se enviará "automáticamente"
     */
int8_t UART2_PopRx( void );
    /* Descripción:
     *      Retorna el primer byte que haya para leer
     *      En caso de error, retorna:
     *          BUFFER_VACIO  =>  No hay dato para leer
     */
int8_t UART2_Transmitir( const void *Mensaje, uint16_t Size );
    /* Descripción:
     *      Hace PushTx Size veces desde Mensaje[0]
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  No hay dato para transmitir en Mensaje
     *          BUFFER_OVERSIZE =>  Size es más grande que el tamaño del buffer de Transmisión
     *          BUFFER_OVERSIZE =>  Size es más grande que Mensaje
     *          ENVIADO         =>  Size bytes fueron enviados al buffer de transmisión
     */
int8_t UART2_Transmitir_String( int8_t *Mensaje );
    /* Descripción:
     *      Hace PushTx hasta el primer '\0' en Mensaje
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  No hay dato para transmitir en Mensaje
     *          ENVIADO         =>  El string completo fue enviado al buffer de transmisión
     */
int8_t UART2_Recibir_String( int8_t *Mensaje, uint32_t Cant_Max );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace.
     *      No se realizarán mas de Cant_Max PopRx.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBIENDO_MENSAJE          =>  Hizo un PopRx exitoso, pero no recibió un '\0'
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron Cant_Max bytes, y nunca se recibió un '\0'
     *          MENSAJE_RECIBIDO_COMPLETO   =>  Se recibió un String Completo.
     */
int8_t UART2_Transmitir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final );
    /* Descripción:
     *      Transmite el Mensaje completo, es decir: 'Char_Inicial' + "Mensaje" + 'Char_Final'.
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  Mensaje está vacío
     *          BUFFER_OVERSIZE =>  El mensaje completo es más largo que el tamaño del buffer de transmisión
     *          ENVIADO         =>  El mensaje completo fue enviado al buffer de transmisión
     */
int8_t UART2_Recibir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace, excluyendo Char_Inicial y Char_Final.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBI_BASURA               =>  Se recibió algo antes de Char_Inicial
     *          RECIBIENDO_MENSAJE          =>  Hizo un PopRx exitoso, está armando el String
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron MAX_TRAMA_RECIBIDA bytes, y nunca se recibió un 'Char_Final'
     *          MENSAJE_RECIBIDO_COMPLETO   =>  Se recibió un Mensaje completo y ya tenemos el String listo.
     */
int8_t UART2_Recibir_Dato_o_Comando( const void *Mensaje );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace, excluyendo
     *      CHAR_COMANDO_INICIAL / FINAL o CHAR_DATO_INICIAL / FINAL.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBI_BASURA               =>  Se recibió algo antes de Char_Inicial
     *          RECIBIENDO_MENSAJE          =>  Hizo un PopRx exitoso, está armando el String
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron MAX_TRAMA_RECIBIDA bytes, y nunca se recibió un 'Char_Final'
     *          COMANDO_RECIBIDO            =>  Se recibió un Comando completo y ya tengo el comando en el string Mensaje.
     *          DATO_RECIBIDO               =>  Se recibió un Dato completo y ya tengo el dato en el string Mensaje.
     */

int8_t UART2_Inicializar_ESP8266( void );
    /* Descripción:
     *      Inicializa el módulo ESP8266.
     *          "AT"
     *          "AT+UART_DEF=115200,8,1,0,0"
     *          "AT+RST"
     *          "AT+CWAUTOCONN=0"
     *          "AT+CWMODE_DEF=1"
     */
int8_t UART2_Transmitir_ESP8266( const void *Mensaje );
    /* Descripción:
     *      Transmite Comandos predeterminados de una tabla de comandos, al módulo ESP8266.
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  No existe el Comando pasado en la tabla
     *          ENVIADO         =>  El mensaje completo fue enviado al buffer de transmisión
     */
int8_t UART2_Recibir_ESP8266( const void *Mensaje, uint16_t Cant_Max );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace hasta Cant_Max veces, cambiando el \r y \n del final, por un \0.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBIENDO_MENSAJE          =>  Hizo al menos un PopRx exitoso, se está armando el String
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron Cant_Max bytes, y nunca se recibió un '\r'
     *          MENSAJE_RECIBIDO_COMPLETO   =>  Se recibió un Mensaje completo y ya tenemos el String listo.
     */
int8_t UART2_Conectar_ESP8266( void );
    /* Descripción:
     *      Se encarga de la conexión del ESP8266 a _NOMBRE_RED_WIFI_SSID_, con la contraseña _PASSWORD_RED_WIFI_. Luego se coencta a la IP
     *      _IP_NUMBER_, en el puerto _PORT_NUMBER_. Retorna el estado actual de la conexion, a medida que se va conectando ( MDE )
     *      Valores de retorno:
     *          AUN_NO_INICIALIZADO         =>  Se está inicializando el módulo
     *
     *          _AT_                        =>  Se está comprobando el módulo
     *          _AT_UART_DEF_               =>  Se está configurando la comunicación con el módulo
     *          _AT_CWLAPOPT_               =>  Se está configurando la busqueda de redes WiFi del módulo
     *          _AT_CWLAP_                  =>  Se está buscando redes WiFi
     *          _AT_CWJAP_CUR_              =>  Se está conectando a la Red WiFi definida
     *          _AT_CIPSTART_               =>  Se está conectando al Socket TCP definido
     *
     *          _ESP8266_WIFI_SSID_ERROR_   =>  No se pudo conectar la Red WiFi
     *          _ESP8266_WIFI_PASSWORD_ERROR_   =>  Se encontró la Red WiFi, pero NO se pudo conectar a la misma
     *          _ESP8266_SOCKET_ERROR_      =>  Se conectó a la Red WiFi, pero NO se pudo conectar al Socket TCP
     *
     *          _ESP8266_CONECTADO_         =>  Se conectó a la Red WiFi y al Socket TCP correctamente
     *
     */
int8_t UART2_ESP8266_Enviar( const void *Mensaje, uint16_t Cant_Max );



/*  FUNCIONES PARA UART3    */

void UART3_PushTx( int8_t dato );
    /* Descripción:
     *      Pasa Dato al buffer de transmisión, desde el cual se enviará "automáticamente"
     */
int8_t UART3_PopRx( void );
    /* Descripción:
     *      Retorna el primer byte que haya para leer
     *      En caso de error, retorna:
     *          BUFFER_VACIO  =>  No hay dato para leer
     */
int8_t UART3_Transmitir( const void *Mensaje, uint16_t Size );
    /* Descripción:
     *      Hace PushTx Size veces desde Mensaje[0]
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  No hay dato para transmitir en Mensaje
     *          BUFFER_OVERSIZE =>  Size es más grande que el tamaño del buffer de Transmisión
     *          BUFFER_OVERSIZE =>  Size es más grande que Mensaje
     *          ENVIADO         =>  Size bytes fueron enviados al buffer de transmisión
     */
int8_t UART3_Transmitir_String( int8_t *Mensaje );
    /* Descripción:
     *      Hace PushTx hasta el primer '\0' en Mensaje
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  No hay dato para transmitir en Mensaje
     *          ENVIADO         =>  El string completo fue enviado al buffer de transmisión
     */
int8_t UART3_Recibir_String( int8_t *Mensaje, uint32_t Cant_Max );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace.
     *      No se realizarán mas de Cant_Max PopRx.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBIENDO_MENSAJE          =>  Hizo un PopRx exitoso, pero no recibió un '\0'
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron Cant_Max bytes, y nunca se recibió un '\0'
     *          MENSAJE_RECIBIDO_COMPLETO   =>  Se recibió un String Completo.
     */
int8_t UART3_Transmitir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final );
    /* Descripción:
     *      Transmite el Mensaje completo, es decir: 'Char_Inicial' + "Mensaje" + 'Char_Final'.
     *      Valores de retorno:
     *          BUFFER_VACIO    =>  Mensaje está vacío
     *          BUFFER_OVERSIZE =>  El mensaje completo es más largo que el tamaño del buffer de transmisión
     *          ENVIADO         =>  El mensaje completo fue enviado al buffer de transmisión
     */
int8_t UART3_Recibir_Trama( const void *Mensaje, int8_t Char_Inicial, int8_t Char_Final );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace, excluyendo Char_Inicial y Char_Final.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBI_BASURA               =>  Se recibió algo antes de Char_Inicial
     *          RECIBIENDO_MENSAJE          =>  Hizo un PopRx exitoso, está armando el String
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron MAX_TRAMA_RECIBIDA bytes, y nunca se recibió un 'Char_Final'
     *          MENSAJE_RECIBIDO_COMPLETO   =>  Se recibió un Mensaje completo y ya tenemos el String listo.
     */
int8_t UART3_Recibir_Dato_o_Comando( const void *Mensaje );
    /* Descripción:
     *      Arma un String que guarda en Mensaje, con los PopRx que hace, excluyendo
     *      CHAR_COMANDO_INICIAL / FINAL o CHAR_DATO_INICIAL / FINAL.
     *      Valores de retorno:
     *          BUFFER_VACIO                =>  No hay dato para leer
     *          RECIBI_BASURA               =>  Se recibió algo antes de Char_Inicial
     *          RECIBIENDO_MENSAJE          =>  Hizo un PopRx exitoso, está armando el String
     *          MENSAJE_RECIBIDO_CORTADO    =>  Se recibieron MAX_TRAMA_RECIBIDA bytes, y nunca se recibió un 'Char_Final'
     *          COMANDO_RECIBIDO            =>  Se recibió un Comando completo y ya tengo el comando en el string Mensaje.
     *          DATO_RECIBIDO               =>  Se recibió un Dato completo y ya tengo el dato en el string Mensaje.
     */

#endif /* PRIMITIVAS_INC_PR_UART_H_ */
