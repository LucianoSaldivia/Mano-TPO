/*******************************************************************************************************************************//**
 *
 * @file		MDE_Guante_Mano.c
 * @brief		--Descripción del Módulo--
 * @date		Dec 04, 2018
 * @author		Esteban Chiama
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/
#include "MDE_Guante_Mano.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

// estado
#define RESET		20
#define	INACTIVE	21
#define ACTIVE		22

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

static volatile uint8_t estado_Guante_Mano = RESET;

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

void MDE_Guante_Mano(volatile uint8_t *main_status){
	uint8_t key = 0;
	Lecturas_Mano_1000 ManoRecibida;

	// caso: otra MDE en uso.
	if( (*main_status == BUSY) && (estado_Guante_Mano == INACTIVE) ){
		return;
	}

	switch(estado_Guante_Mano){

	case RESET:
		estado_Guante_Mano = INACTIVE;
		break;

	case INACTIVE:
//		key = GetKey();
//		// caso: Botón de comienzo
//		if( key == SW1 ){
//			key = NO_KEY;
//			estado_Guante_Mano = ACTIVE;
//			*main_status = BUSY;
////			LCD_DisplayMsg( "M: Guante > Mano", LCD_RENGLON_1, 0);
//			// LED del stick como testigo
//			LED_Set(LED_STICK, LED_STICK_ON);
//
//			// Habilitamos PWM
//			PWM_Enable_5_Channels();
//		}
		if( command == MODO_GUANTE_MANO_START ){
			command = NO_COMMAND;
			estado_Guante_Mano = ACTIVE;
			*main_status = BUSY;
//			LCD_DisplayMsg( "M: Guante > Mano", LCD_RENGLON_1, 0);
			// LED del stick como testigo
			LED_Set(LED_STICK, LED_STICK_ON);

			// Habilitamos PWM
			PWM_Enable_5_Channels();
		}
		break;

	case ACTIVE:
		// caso: dato recibido por UART
		if( f_U3_Data == DATA_AVAILABLE ){
			f_U3_Data = NO_DATA;
			ManoRecibida = U3_Data_Adaptada;
			PWM_Set_Lecturas( &ManoRecibida );
		}

//		key = GetKey();
//		// caso: Botón de finalización
//		if( key == SW1 ){
//			key = NO_KEY;
//			estado_Guante_Mano = INACTIVE;
//			*main_status = FREE;
//			// para ignorar comandos que hayan llegado en el proceso
//			command = NO_COMMAND;
////			LCD_DisplayMsg("> MANO INACTIVA.", LCD_RENGLON_1, 0);
//			LED_Set(LED_STICK, LED_STICK_OFF);
//
//			// deshabilitamos los PWM
//			PWM_Disable_5_Channels();
//		}

		if( command == MODO_GUANTE_MANO_STOP ){
			command = NO_COMMAND;
			estado_Guante_Mano = INACTIVE;
			*main_status = FREE;
//			LCD_DisplayMsg("> MANO INACTIVA.", LCD_RENGLON_1, 0);
			LED_Set(LED_STICK, LED_STICK_OFF);
			key = GetKey();	// para limpiar el buffer de teclado, ignorar botones que hayan sido apretados en el proceso

			// deshabilitamos los PWM
			PWM_Disable_5_Channels();
		}
		break;

	default:
		estado_Guante_Mano = INACTIVE;
		break;

	}

	// Botón de emergencia, STOP
	key = GetKey();
	if( key == SW4 ){
		key = NO_KEY;
		estado_Guante_Mano = INACTIVE;
		*main_status = FREE;
		// para ignorar comandos que hayan llegado en el proceso
		command = NO_COMMAND;
//			LCD_DisplayMsg("> MANO INACTIVA.", LCD_RENGLON_1, 0);
		LED_Set(LED_STICK, LED_STICK_OFF);

		// deshabilitamos los PWM
		PWM_Disable_5_Channels();
	}
}
