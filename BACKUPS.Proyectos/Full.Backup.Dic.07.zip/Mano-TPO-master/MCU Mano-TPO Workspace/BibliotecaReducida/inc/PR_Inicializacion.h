/*
 * PR_Inicializacion.h
 *
 *  Created on: 21 oct. 2018
 *      Author: augusto
 */

#ifndef PRIMITIVAS_PR_INICIALIZACION_H_
#define PRIMITIVAS_PR_INICIALIZACION_H_

void Inicializacion( void );

#endif /* PRIMITIVAS_PR_INICIALIZACION_H_ */
