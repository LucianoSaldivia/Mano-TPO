/*
 * Config.h
 *
 *  Created on: 24 oct. 2018
 *      Author: augusto
 */

#ifndef PRIMITIVAS_CONFIG_H_
#define PRIMITIVAS_CONFIG_H_

//#define	MODULO_ADC_ACTIVO
//#define	MODULO_UART_ACTIVO
#define	MODULO_LCD_ACTIVO
#define	MODULO_TIMERS_ACTIVO

#endif /* PRIMITIVAS_CONFIG_H_ */
