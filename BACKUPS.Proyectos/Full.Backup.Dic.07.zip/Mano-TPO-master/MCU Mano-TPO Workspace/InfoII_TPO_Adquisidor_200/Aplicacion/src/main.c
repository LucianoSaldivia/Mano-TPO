/*
===============================================================================
 Name        : pruebaBiblioteca.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>


int main ( void )
{


	while(1)
	{

	}
}
