
/*
 * AP_muestreo_mano.h
 *
 *  Created on: Oct 22, 2018
 *      Author: cha
 */

#ifndef INC_AP_MUESTREO_MANO_H_
#define INC_AP_MUESTREO_MANO_H_


void Preparar_y_Enviar( void );
void EnviarMano( Muestras_Medias_t ManoMuestreada );


#endif /* INC_AP_MUESTREO_MANO_H_ */
