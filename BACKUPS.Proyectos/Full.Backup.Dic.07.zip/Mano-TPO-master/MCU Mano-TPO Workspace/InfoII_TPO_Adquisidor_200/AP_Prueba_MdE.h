/*
 * mensaje.h
 *
 *  Created on: 5 jun. 2018
 *      Author: gabriel
 */

#ifndef AP_PRUEBA1_H_
#define AP_PRUEBA1_H_

//Relays
#define RELAY0 0
#define RELAY1 1
#define RELAY2 2
#define RELAY3 3

//Estados
#define	ESPERANDO	1
#define	NUEVA_TECLA	2


//Prototipos de funciones
void MaquinaEstadosPrueba(void);

#endif /* AP_PRUEBA1_H_ */
