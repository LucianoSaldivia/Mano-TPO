<<<<<<< HEAD
# gittest
=======
# Mano-TPO
Info II TPO - UTN FRBA
>>>>>>> 0189edfaaa218e62e0d220272faf69a804b5c712


".git" en :
/Carpeta personal/Informática_II/Mano_TPO
