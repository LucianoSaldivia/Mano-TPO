/*******************************************************************************************************************************//**
 *
 * @file		DR_PWM.c
 * @brief		Descripcion del modulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include "../inc/DR_PWM.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define DIVISIONES_POR_CICLO        20000
#define VALOR_PR                    24

#define VALOR_INICIAL_1             500
#define VALOR_INICIAL_2             500
#define VALOR_INICIAL_3             500
#define VALOR_INICIAL_4             500
#define VALOR_INICIAL_5             500
#define VALOR_INICIAL_6             500

#define BORRAR_PWM_MR0_IIR_FLAG     PWM1IR &= ~( PWM_MR0_IIR_FLAG )
#define BORRAR_PWM_MR1_IIR_FLAG     PWM1IR &= ~( PWM_MR1_IIR_FLAG )
#define BORRAR_PWM_MR2_IIR_FLAG     PWM1IR &= ~( PWM_MR2_IIR_FLAG )
#define BORRAR_PWM_MR3_IIR_FLAG     PWM1IR &= ~( PWM_MR3_IIR_FLAG )
#define BORRAR_PWM_MR4_IIR_FLAG     PWM1IR &= ~( PWM_MR4_IIR_FLAG )
#define BORRAR_PWM_MR5_IIR_FLAG     PWM1IR &= ~( PWM_MR5_IIR_FLAG )
#define BORRAR_PWM_MR6_IIR_FLAG     PWM1IR &= ~( PWM_MR6_IIR_FLAG )

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE datoS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

volatile uint32_t Buffer_TH[ CANT_DEDOS ];

volatile uint8_t _BUFF_TH_EN_CURSO;

static volatile uint8_t _FLAG_PWM_1_DISABLED = 1;
static volatile uint8_t _FLAG_PWM_2_DISABLED = 1;
static volatile uint8_t _FLAG_PWM_3_DISABLED = 1;
static volatile uint8_t _FLAG_PWM_4_DISABLED = 1;
static volatile uint8_t _FLAG_PWM_5_DISABLED = 1;
static volatile uint8_t _FLAG_PWM_6_DISABLED = 1;

static volatile uint8_t _FLAGS_INTERRUPCIONES = 0;

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

void PWM1_IRQHandler (void){
    uint16_t iir;

    do{
        iir = PWM1IR;

        if( iir & PWM_MR0_IIR_FLAG ){   // Interrupcion por MR0
            _FLAGS_INTERRUPCIONES = 0;
            BORRAR_PWM_MR0_IIR_FLAG;
        }
        if( iir & PWM_MR1_IIR_FLAG ){   // Interrupcion por MR1
            _FLAGS_INTERRUPCIONES ++;
            BORRAR_PWM_MR1_IIR_FLAG;
        }
        if( iir & PWM_MR2_IIR_FLAG ){   // Interrupcion por MR2
            _FLAGS_INTERRUPCIONES ++;
            BORRAR_PWM_MR2_IIR_FLAG;
        }
        if( iir & PWM_MR3_IIR_FLAG ){   // Interrupcion por MR3
            _FLAGS_INTERRUPCIONES ++;
            BORRAR_PWM_MR3_IIR_FLAG;
        }
        if( iir & PWM_MR4_IIR_FLAG ){   // Interrupcion por MR4
            _FLAGS_INTERRUPCIONES ++;
            BORRAR_PWM_MR4_IIR_FLAG;
        }
        if( iir & PWM_MR5_IIR_FLAG ){   // Interrupcion por MR5
            _FLAGS_INTERRUPCIONES ++;
            BORRAR_PWM_MR5_IIR_FLAG;
        }
    } while( iir & PWM_MR0_IIR_FLAG ||
             iir & PWM_MR1_IIR_FLAG ||
             iir & PWM_MR2_IIR_FLAG ||
             iir & PWM_MR3_IIR_FLAG ||
             iir & PWM_MR4_IIR_FLAG ||
             iir & PWM_MR5_IIR_FLAG );   // Mientras que haya una interrupcion

    if( _FLAGS_INTERRUPCIONES == 5 ){
        PWM1_Actualizar_5Canales();
    }

}



/*  FUNCIONES PARA TPO_INFO_2    */

void PWM1_Init_5Canales( void ){

    PCONP |= ( 0x01 << 6 );         // Energizamos Perif. PWM

    PCLKSEL0 &= ~( 0x03 << 12 );    // PCLK = CCLK / 4 = 25 MHz

    PWM1CTCR &= ~( 0x03 << 0 );     // Counter Mode

    PWM1_Init_Canal( DEDO_PULGAR , VALOR_INICIAL_1 );
    PWM1_Init_Canal( DEDO_INDICE , VALOR_INICIAL_2 );
    PWM1_Init_Canal( DEDO_MAYOR  , VALOR_INICIAL_3 );
    PWM1_Init_Canal( DEDO_ANULAR , VALOR_INICIAL_4 );
    PWM1_Init_Canal( DEDO_MENOR  , VALOR_INICIAL_5 );

    PWM1TCR &= ~( 0x01 << 1 );      // Counter Reset
    PWM1MCR |= ( 0x01 << 1 );       // Reset on PWM1MR0 match

    PWM1MCR |= ( 0x01 << 0 );       // Activo Interrupciones cuando TC = MR0
    PWM1MCR |= ( 0x01 << 3 );       // Activo Interrupciones cuando TC = MR1
    PWM1MCR |= ( 0x01 << 6 );       // Activo Interrupciones cuando TC = MR2
    PWM1MCR |= ( 0x01 << 9 );       // Activo Interrupciones cuando TC = MR3
    PWM1MCR |= ( 0x01 << 12 );      // Activo Interrupciones cuando TC = MR4
    PWM1MCR |= ( 0x01 << 15 );      // Activo Interrupciones cuando TC = MR5

    PWM1MR0 = DIVISIONES_POR_CICLO; // Set PWM cycle
    PWM1LER |= ( 0x01 << 0 );

    ISER0 |= ( 0x01 << 9 );         // Habilito las interrupciones desde el micro

}

void PWM1_Actualizar_5Canales( void ){

    // Set     ==> Cambio MR_N y Activo LER
    // Cargo los nuevos MR
    PWM1MR1 = Buffer_TH[ DEDO_PULGAR ];
    PWM1MR2 = Buffer_TH[ DEDO_INDICE ];
    PWM1MR3 = Buffer_TH[ DEDO_MAYOR  ];
    PWM1MR4 = Buffer_TH[ DEDO_ANULAR ];
    PWM1MR5 = Buffer_TH[ DEDO_MENOR  ];

    // Aviso para que lo haga efectivos todos los nuevos MR
    PWM1LER |= ( 0x01 << 1 );
    PWM1LER |= ( 0x01 << 2 );
    PWM1LER |= ( 0x01 << 3 );
    PWM1LER |= ( 0x01 << 4 );
    PWM1LER |= ( 0x01 << 5 );

}



//  Funciones genéricas para todos los 6 canales PWM1_1 ~ PWM1_6

void PWM1_Init_Canal( uint8_t Canal, uint32_t Valor_Inicial ){

        switch ( Canal ) {  // SetPINSEL y los configuro como SINGLE EDGE

                case DEDO_PULGAR:
                case CANAL_1:
                    	SetPINSEL( P2, 0, PINSEL_FUNC1 );
                		// No se configura, funciona igual para
                        // Single EDGE o Double EDGE
                        break;

                case DEDO_INDICE:
                case CANAL_2:
                        SetPINSEL( P2, 1, PINSEL_FUNC1 );
                        PWM1PCR &= ~( 0x01 << 2 );  // Ponemos en modo Single EDGE
                        break;

                case DEDO_MAYOR:
                case CANAL_3:
                        SetPINSEL( P2, 2, PINSEL_FUNC1 );
                        PWM1PCR &= ~( 0x01 << 3 );  // Ponemos en modo Single EDGE
                        break;

                case DEDO_ANULAR:
                case CANAL_4:
                        SetPINSEL( P2, 3, PINSEL_FUNC1 );
                        PWM1PCR &= ~( 0x01 << 4 );  // Ponemos en modo Single EDGE
                        break;

                case DEDO_MENOR:
                case CANAL_5:
                        SetPINSEL( P2, 4, PINSEL_FUNC1 );
                        PWM1PCR &= ~( 0x01 << 5 );  // Ponemos en modo Single EDGE
                        break;

                case CANAL_6:
                        SetPINSEL( P2, 5, PINSEL_FUNC1 );
                        PWM1PCR &= ~( 0x01 << 6 );  // Ponemos en modo Single EDGE
                        break;

                default:            // default = DEDO_PULGAR o CANAL_1
                        SetPINSEL( P2, 0, PINSEL_FUNC1 );
                        // Modo Single EDGE por default
                        break;
        }

        PWM1PR = VALOR_PR;                    // Prescale
            // CCLK = 100 Mhz
            // PCLK = CCLK / 4 = 25 MHz
            //    con PR = 24
            // Count.Freq. = PCLK / ( PR + 1 ) = 1 MHz

        switch ( Canal ) {  // Cargo Valor_Inicial y aviso para que se haga efectivo

                case DEDO_PULGAR:
                case CANAL_1:
                        PWM1MR1 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 1 );
                        break;

                case DEDO_INDICE:
                case CANAL_2:
                        PWM1MR2 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 2 );
                        break;

                case DEDO_MAYOR:
                case CANAL_3:
                        PWM1MR3 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 3 );
                        break;

                case DEDO_ANULAR:
                case CANAL_4:
                        PWM1MR4 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 4 );
                        break;

                case DEDO_MENOR:
                case CANAL_5:
                        PWM1MR5 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 5 );
                        break;

                case CANAL_6:
                        PWM1MR6 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 6 );
                        break;

                default:            // default = DEDO_PULGAR o CANAL1
                        PWM1MR1 = Valor_Inicial;
                        PWM1LER |= ( 0x01 << 1 );
                        break;
        }
}

void PWM1_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Counter Enable
    PWM1TCR |= ( 0x01 << 3 );   // PWM Enable

    PWM1PCR |= ( 0x01 << 9 );   // Enable PWM1_1
    PWM1PCR |= ( 0x01 << 10 );  // Enable PWM1_2
    PWM1PCR |= ( 0x01 << 11 );  // Enable PWM1_3
    PWM1PCR |= ( 0x01 << 12 );  // Enable PWM1_4
    PWM1PCR |= ( 0x01 << 13 );  // Enable PWM1_5
    PWM1PCR |= ( 0x01 << 14 );  // Enable PWM1_6
}

void PWM1_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 9 );  // Disable PWM1_1
    PWM1PCR &= ~( 0x01 << 10 ); // Disable PWM1_2
    PWM1PCR &= ~( 0x01 << 11 ); // Disable PWM1_3
    PWM1PCR &= ~( 0x01 << 12 ); // Disable PWM1_4
    PWM1PCR &= ~( 0x01 << 13 ); // Disable PWM1_5
    PWM1PCR &= ~( 0x01 << 14 ); // Disable PWM1_6

    PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
    PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
}



//  Funciones para PWM1_1

void PWM1_1_Set( uint32_t Valor_Lectura ){

    // Set     ==> Cambio MR_N y Activo LER

    PWM1MR1 = Valor_Lectura;    // Cargo el nuevo MR
    PWM1LER |= ( 0x01 << 1 );   // Aviso para que lo haga efectivo
}

void PWM1_1_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Enable Counter
    PWM1TCR |= ( 0x01 << 3 );   // Enable PWM Mode

    PWM1PCR |= ( 0x01 << 9 );   // Enable PWM1_1 Output
    _FLAG_PWM_1_DISABLED = 0;
}

void PWM1_1_Pause( void ){

    // Start   ==> OUTPUT ENABLE = 0

    PWM1PCR &= ~( 0x01 << 9 );  // Disable PWM1_1 Output
    _FLAG_PWM_1_DISABLED = 1;
}

void PWM1_1_Play( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1PCR |= ( 0x01 << 9 );   // Enable PWM1_1 Output
    _FLAG_PWM_1_DISABLED = 0;
}

void PWM1_1_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 9 );  // Disable PWM1_1 Output
    _FLAG_PWM_1_DISABLED = 1;

    if( _FLAG_PWM_1_DISABLED && _FLAG_PWM_2_DISABLED &&
            _FLAG_PWM_3_DISABLED && _FLAG_PWM_4_DISABLED &&
            _FLAG_PWM_5_DISABLED && _FLAG_PWM_6_DISABLED ){

        PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
        PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    }
}



//  Funciones para PWM1_2

void PWM1_2_Set( uint32_t Valor_Lectura ){

    // Set     ==> Cambio MR_N y Activo LER

    PWM1MR2 = Valor_Lectura;    // Cargo el nuevo MR
    PWM1LER |= ( 0x01 << 2 );   // Aviso para que lo haga efectivo
}

void PWM1_2_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Enable Counter
    PWM1TCR |= ( 0x01 << 3 );   // Enable PWM Mode

    PWM1PCR |= ( 0x01 << 10 );  // Enable PWM1_2 Output
    _FLAG_PWM_2_DISABLED = 0;
}

void PWM1_2_Pause( void ){

    // Start   ==> OUTPUT ENABLE = 0

    PWM1PCR &= ~( 0x01 << 10 ); // Disable PWM1_2 Output
    _FLAG_PWM_2_DISABLED = 1;
}

void PWM1_2_Play( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1PCR |= ( 0x01 << 10 );  // Enable PWM1_2 Output
    _FLAG_PWM_2_DISABLED = 0;
}

void PWM1_2_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 10 ); // Disable PWM1_2 Output
    _FLAG_PWM_2_DISABLED = 1;

    if( _FLAG_PWM_1_DISABLED && _FLAG_PWM_2_DISABLED &&
            _FLAG_PWM_3_DISABLED && _FLAG_PWM_4_DISABLED &&
            _FLAG_PWM_5_DISABLED && _FLAG_PWM_6_DISABLED ){

        PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
        PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    }
}



//  Funciones para PWM1_3

void PWM1_3_Set( uint32_t Valor_Lectura ){

    // Set     ==> Cambio MR_N y Activo LER

    PWM1MR3 = Valor_Lectura;    // Cargo el nuevo MR
    PWM1LER |= ( 0x01 << 3 );   // Aviso para que lo haga efectivo
}

void PWM1_3_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Enable Counter
    PWM1TCR |= ( 0x01 << 3 );   // Enable PWM Mode

    PWM1PCR |= ( 0x01 << 11 );  // Enable PWM1_3 Output
    _FLAG_PWM_3_DISABLED = 0;
}

void PWM1_3_Pause( void ){

    // Start   ==> OUTPUT ENABLE = 0

    PWM1PCR &= ~( 0x01 << 11 ); // Disable PWM1_3 Output
    _FLAG_PWM_3_DISABLED = 1;
}

void PWM1_3_Play( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1PCR |= ( 0x01 << 11 );  // Enable PWM1_3 Output
    _FLAG_PWM_3_DISABLED = 0;
}

void PWM1_3_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 11 ); // Disable PWM1_3 Output
    _FLAG_PWM_3_DISABLED = 1;

    if( _FLAG_PWM_1_DISABLED && _FLAG_PWM_2_DISABLED &&
            _FLAG_PWM_3_DISABLED && _FLAG_PWM_4_DISABLED &&
            _FLAG_PWM_5_DISABLED && _FLAG_PWM_6_DISABLED ){

        PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
        PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    }
}



//  Funciones para PWM1_4

void PWM1_4_Set( uint32_t Valor_Lectura ){

    // Set     ==> Cambio MR_N y Activo LER

    PWM1MR4 = Valor_Lectura;    // Cargo el nuevo MR
    PWM1LER |= ( 0x01 << 4 );   // Aviso para que lo haga efectivo
}

void PWM1_4_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Enable Counter
    PWM1TCR |= ( 0x01 << 3 );   // Enable PWM Mode

    PWM1PCR |= ( 0x01 << 12 );  // Enable PWM1_4 Output
    _FLAG_PWM_4_DISABLED = 0;
}

void PWM1_4_Pause( void ){

    // Start   ==> OUTPUT ENABLE = 0

    PWM1PCR &= ~( 0x01 << 12 ); // Disable PWM1_4 Output
    _FLAG_PWM_4_DISABLED = 1;
}

void PWM1_4_Play( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1PCR |= ( 0x01 << 12 );  // Enable PWM1_4 Output
    _FLAG_PWM_4_DISABLED = 0;
}

void PWM1_4_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 12 ); // Disable PWM1_4 Output
    _FLAG_PWM_4_DISABLED = 1;

    if( _FLAG_PWM_1_DISABLED && _FLAG_PWM_2_DISABLED &&
            _FLAG_PWM_3_DISABLED && _FLAG_PWM_4_DISABLED &&
            _FLAG_PWM_5_DISABLED && _FLAG_PWM_6_DISABLED ){

        PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
        PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    }
}



//  Funciones para PWM1_5

void PWM1_5_Set( uint32_t Valor_Lectura ){

    // Set     ==> Cambio MR_N y Activo LER

    PWM1MR5 = Valor_Lectura;    // Cargo el nuevo MR
    PWM1LER |= ( 0x01 << 5 );   // Aviso para que lo haga efectivo
}

void PWM1_5_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Enable Counter
    PWM1TCR |= ( 0x01 << 3 );   // Enable PWM Mode

    PWM1PCR |= ( 0x01 << 13 );  // Enable PWM1_5 Output
    _FLAG_PWM_5_DISABLED = 0;
}

void PWM1_5_Pause( void ){

    // Start   ==> OUTPUT ENABLE = 0

    PWM1PCR &= ~( 0x01 << 13 ); // Disable PWM1_5 Output
    _FLAG_PWM_5_DISABLED = 1;
}

void PWM1_5_Play( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1PCR |= ( 0x01 << 13 );  // Enable PWM1_5 Output
    _FLAG_PWM_5_DISABLED = 0;
}

void PWM1_5_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 13 ); // Disable PWM1_5 Output
    _FLAG_PWM_5_DISABLED = 1;

    if( _FLAG_PWM_1_DISABLED && _FLAG_PWM_2_DISABLED &&
            _FLAG_PWM_3_DISABLED && _FLAG_PWM_4_DISABLED &&
            _FLAG_PWM_5_DISABLED && _FLAG_PWM_6_DISABLED ){

        PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
        PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    }
}



//  Funciones para PWM1_6

void PWM1_6_Set( uint32_t Valor_Lectura ){

    // Set     ==> Cambio MR_N y Activo LER

    PWM1MR6 = Valor_Lectura;    // Cargo el nuevo MR
    PWM1LER |= ( 0x01 << 6 );   // Aviso para que lo haga efectivo
}

void PWM1_6_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1TCR |= ( 0x01 << 0 );   // Enable Counter
    PWM1TCR |= ( 0x01 << 3 );   // Enable PWM Mode

    PWM1PCR |= ( 0x01 << 14 );  // Enable PWM1_6 Output
    _FLAG_PWM_6_DISABLED = 0;
}

void PWM1_6_Pause( void ){

    // Start   ==> OUTPUT ENABLE = 0

    PWM1PCR &= ~( 0x01 << 14 ); // Disable PWM1_6 Output
    _FLAG_PWM_6_DISABLED = 1;
}

void PWM1_6_Play( void ){

    // Start   ==> OUTPUT ENABLE = 1

    PWM1PCR |= ( 0x01 << 14 );  // Enable PWM1_6 Output
    _FLAG_PWM_6_DISABLED = 0;
}

void PWM1_6_Stop( void ){

    // Stop    ==> ENABLE = 0

    PWM1PCR &= ~( 0x01 << 14 ); // Disable PWM1_6 Output
    _FLAG_PWM_6_DISABLED = 1;

    if( _FLAG_PWM_1_DISABLED && _FLAG_PWM_2_DISABLED &&
            _FLAG_PWM_3_DISABLED && _FLAG_PWM_4_DISABLED &&
            _FLAG_PWM_5_DISABLED && _FLAG_PWM_6_DISABLED ){

        PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
        PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    }
}





