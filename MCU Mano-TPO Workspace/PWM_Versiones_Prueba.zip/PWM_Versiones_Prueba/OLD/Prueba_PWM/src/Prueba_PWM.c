/*
===============================================================================
 Name        : Prueba_PWM.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>

// TODO: insert other include files here

#include "PR_Teclado.h"
#include "PR_lcd.h"
#include "PR_Inicializacion.h"
#include "Tipos.h"
#include "PR_Relays.h"
#include "../inc/AP_Prueba_PWM.h"

#define RELAY0	0
#define RELAY1	1
#define RELAY2	2
#define RELAY3	3

int main(void) {

    // TODO: insert code here

	Inicializacion();
	PWM1_Init_5Canales();

	LCD_Display( "                ", LCD_RENGLON0, 0 );
	LCD_Display( "                ", LCD_RENGLON1, 0 );
	LCD_Display( "PWM Esperando   ", LCD_RENGLON0, 0 );
	LCD_Display( "Tecla => Iniciar", LCD_RENGLON1, 0 );

	Relays( RELAY0, OFF );
	Relays( RELAY1, OFF );
	Relays( RELAY2, OFF );
	Relays( RELAY3, OFF );

    // Enter an infinite loop, just incrementing a counter
    while(1) {
    	MDE_PRUEBA_PWM();
    }
    return 0 ;
}
