/*******************************************************************************************************************************//**
 *
 * @file		PR_PWM.c
 * @brief		Descripcion del modulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include "../inc/PR_PWM.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define DIVISIONES_MINIMAS_TH       1000

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

void PWM_Set_Lecturas( Lecturas_Mano_4096 *Lecturas ){
    Buffer_TH[ DEDO_PULGAR ] = Convertir( Lecturas->Pulgar ) + DIVISIONES_MINIMAS_TH;
    Buffer_TH[ DEDO_INDICE ] = Convertir( Lecturas->Indice ) + DIVISIONES_MINIMAS_TH;
    Buffer_TH[ DEDO_MAYOR  ] = Convertir( Lecturas->Mayor  ) + DIVISIONES_MINIMAS_TH;
    Buffer_TH[ DEDO_MAYOR  ] = Convertir( Lecturas->Anular ) + DIVISIONES_MINIMAS_TH;
    Buffer_TH[ DEDO_MENOR  ] = Convertir( Lecturas->Menor  ) + DIVISIONES_MINIMAS_TH;
}

uint16_t Convertir( uint16_t Lectura_4096 ){
    uint16_t Lectura_1000, Lectura_1024 = Lectura_4096 / 4;

    if( Lectura_1024 > 1024 ){
        Lectura_1024 = 1024;
    }

    if( Lectura_1024 < 501 ){
        if( Lectura_1024 < 250 ){
            if( Lectura_1024 < 125 ){
                if( Lectura_1024 < 84 ){
                    if( Lectura_1024 < 42 ){
                        Lectura_1000 = Lectura_1024;         // 0 <= Lectura_1024 < 42
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 1;     // 42 <= Lectura_1024 < 84
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 2;         // 84 <= Lectura_1024 < 125
                }
            }
            else{
                if( Lectura_1024 < 209 ){
                    if( Lectura_1024 < 167 ){
                        Lectura_1000 = Lectura_1024 - 3;     // 125 <= Lectura_1024 < 167
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 4;     // 167 <= Lectura_1024 < 209
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 5;         // 209 <= Lectura_1024 < 250
                }
            }
        }
        else{
            if( Lectura_1024 < 375 ){
                if( Lectura_1024 < 333 ){
                    if( Lectura_1024 < 292 ){
                        Lectura_1000 = Lectura_1024 - 6;     // 250 <= Lectura_1024 < 292
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 7;     // 292 <= Lectura_1024 < 333
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 8;         // 333 <= Lectura_1024 < 375
                }
            }

            else{
                if( Lectura_1024 < 459 ){
                    if( Lectura_1024 < 417 ){
                        Lectura_1000 = Lectura_1024 - 9;     // 375 <= Lectura_1024 < 417
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 10;    // 417 <= Lectura_1024 < 459
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 11;        // 459 <= Lectura_1024 < 501
                }
            }
        }
    }
    else{
        if( Lectura_1024 < 751 ){
            if( Lectura_1024 < 626 ){
                if( Lectura_1024 < 548 ){
                    if( Lectura_1024 < 542 ){
                        Lectura_1000 = Lectura_1024 - 12;    // 501 <= Lectura_1024 < 542
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 13;    // 542 <= Lectura_1024 < 548
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 14;        // 548 <= Lectura_1024 < 626
                }
            }
            else{
                if( Lectura_1024 < 709 ){
                    if( Lectura_1024 < 667 ){
                        Lectura_1000 = Lectura_1024 - 15;    // 626 <= Lectura_1024 < 667
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 16;    // 667 <= Lectura_1024 < 709
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 17;        // 709 <= Lectura_1024 < 751
                }
            }
        }
        else{
            if( Lectura_1024 < 917 ){
                if( Lectura_1024 < 834 ){
                    if( Lectura_1024 < 792 ){
                        Lectura_1000 = Lectura_1024 - 18;    // 751 <= Lectura_1024 < 792
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 19;    // 792 <= Lectura_1024 < 834
                    }
                }
                else{
                    if( Lectura_1024 < 876 ){
                        Lectura_1000 = Lectura_1024 - 20;    // 834 <= Lectura_1024 < 876
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 21;    // 876 <= Lectura_1024 < 917
                    }
                }
            }
            else{
                if( Lectura_1024 < 1000 ){
                    if( Lectura_1024 < 959 ){
                        Lectura_1000 = Lectura_1024 - 22;    // 917 <= Lectura_1024 < 959
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 23;    // 959 <= Lectura_1024 < 1000
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 24;        // 1000 <= Lectura_1024 < 1024
                }
            }
        }
    }

    return Lectura_1000;
}

void PWM_Get_Lecturas( Lecturas_Mano_4096 *Lecturas ){
    Lecturas->Pulgar = ( Buffer_TH[ DEDO_PULGAR ] - DIVISIONES_MINIMAS_TH ) * 4;
    Lecturas->Indice = ( Buffer_TH[ DEDO_INDICE ] - DIVISIONES_MINIMAS_TH ) * 4;
    Lecturas->Mayor  = ( Buffer_TH[ DEDO_MAYOR  ] - DIVISIONES_MINIMAS_TH ) * 4;
    Lecturas->Anular = ( Buffer_TH[ DEDO_PULGAR ] - DIVISIONES_MINIMAS_TH ) * 4;
    Lecturas->Menor  = ( Buffer_TH[ DEDO_MAYOR  ] - DIVISIONES_MINIMAS_TH ) * 4;
}




