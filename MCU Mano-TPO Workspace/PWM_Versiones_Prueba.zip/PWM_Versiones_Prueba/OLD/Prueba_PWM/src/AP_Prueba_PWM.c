/*
 * AP_PRUEBA_PWM.c
 *
 *  Created on: 4 nov. 2018
 *      Author: lsldv
 */


#define ESPERANDO_TECLA		0
#define	ESPERANDO_PAUSA		1

#include "../inc/AP_Prueba_PWM.h"
#include "PR_Teclado.h"
#include "PR_lcd.h"
#include "PR_Relays.h"

#define RELAY0	0
#define RELAY1	1
#define RELAY2	2
#define RELAY3	3


void MDE_PRUEBA_PWM( void ){
	static Lecturas_Mano_4096 S_Lectura;
	static uint8_t Estado = ESPERANDO_TECLA;
	static uint8_t PWM1_Started = 0;

	uint8_t Tecla;

	S_Lectura.Pulgar = 2048;
	S_Lectura.Indice = 2048;
	S_Lectura.Mayor = 2048;
	S_Lectura.Anular = 2048;
	S_Lectura.Menor = 2048;

	Tecla = GetKey();

	if( Tecla == NO_KEY ){
		return;
	}

	switch( Estado ){
		case ESPERANDO_TECLA:

			if( Tecla == SW_1 || Tecla == SW_2 || Tecla == SW_3 || Tecla == SW_4 ){
				PWM_Set_Lecturas( &S_Lectura );
				if( PWM1_Started == 0 ){
					PWM1_1_Start();
					PWM1_Started = 1;
				}
				else{
					PWM1_1_Play();
				}

				LCD_Display( "                ", LCD_RENGLON0, 0 );
				LCD_Display( "                ", LCD_RENGLON1, 0 );
				LCD_Display( "PWM Iniciado    ", LCD_RENGLON0, 0 );
				LCD_Display( "Esperando pausa ", LCD_RENGLON1, 0 );
				Relays( RELAY1, OFF );
				Relays( RELAY2, ON );
				Estado = ESPERANDO_PAUSA;
			}

			break;

		case ESPERANDO_PAUSA:

			if( Tecla == SW_1 || Tecla == SW_2 || Tecla == SW_3 || Tecla == SW_4 ){
				PWM1_1_Pause();
				Estado = ESPERANDO_TECLA;

				LCD_Display( "                ", LCD_RENGLON0, 0 );
				LCD_Display( "                ", LCD_RENGLON1, 0 );
				LCD_Display( "PWM Pausado     ", LCD_RENGLON0, 0 );
				LCD_Display( "Esperando play  ", LCD_RENGLON1, 0 );
				Relays( RELAY1, ON );
				Relays( RELAY2, OFF );
			}

			break;

		default:
			Estado = ESPERANDO_TECLA;
			break;
	}



}

