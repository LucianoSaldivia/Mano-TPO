/*******************************************************************************************************************************//**
 *
 * @file		DR_PWM.h
 * @brief		Breve descripción del objetivo del Módulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MODULO
 **********************************************************************************************************************************/

#ifndef DR_PWM_H_
#define DR_PWM_H_

/***********************************************************************************************************************************
 *** INCLUDES GLOBALES
 **********************************************************************************************************************************/

#include "Regs_LPC176x.h"
#include "../../BibliotecaReducida/inc/DR_pinsel.h"
#include "../../BibliotecaReducida/inc/Tipos.h"

/***********************************************************************************************************************************
 *** DEFINES GLOBALES
 **********************************************************************************************************************************/



#define DEDO_PULGAR                 10
#define DEDO_INDICE                 11
#define DEDO_MAYOR                  12
#define DEDO_ANULAR                 13
#define DEDO_MENOR                  14
#define CANT_DEDOS                  15

#define CANAL_1                     0
#define CANAL_2                     1
#define CANAL_3                     2
#define CANAL_4                     3
#define CANAL_5                     4
#define CANAL_6                     5

/***********************************************************************************************************************************
 *** MACROS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES
 **********************************************************************************************************************************/

extern volatile uint32_t Buffer_TH[];
extern volatile uint8_t _BUFF_TH_EN_CURSO;

/***********************************************************************************************************************************
 *** PROTOTIPOS DE FUNCIONES GLOBALES
 **********************************************************************************************************************************/

//  FUNCIONES PARA TPO_INFO_2

void PWM1_Init_5Canales( void );
void PWM1_Actualizar_5Canales( void );

//  Funciones genéricas para todos los 6 canales PWM1_1 ~ PWM1_6

void PWM1_Init_Canal( uint8_t Canal, uint32_t Valor_Inicial );
void PWM1_Start( void );
void PWM1_Stop( void );

//  Funciones para PWM1_1

void PWM1_1_Set( uint32_t Valor_Lectura );
void PWM1_1_Start( void );
void PWM1_1_Pause( void );
void PWM1_1_Play( void );
void PWM1_1_Stop( void );

//  Funciones para PWM1_2

void PWM1_2_Set( uint32_t Valor_Lectura );
void PWM1_2_Start( void );
void PWM1_2_Pause( void );
void PWM1_2_Play( void );
void PWM1_2_Stop( void );

//  Funciones para PWM1_3

void PWM1_3_Set( uint32_t Valor_Lectura );
void PWM1_3_Start( void );
void PWM1_3_Pause( void );
void PWM1_3_Play( void );
void PWM1_3_Stop( void );

//  Funciones para PWM1_4

void PWM1_4_Set( uint32_t Valor_Lectura );
void PWM1_4_Start( void );
void PWM1_4_Pause( void );
void PWM1_4_Play( void );
void PWM1_4_Stop( void );

//  Funciones para PWM1_5

void PWM1_5_Set( uint32_t Valor_Lectura );
void PWM1_5_Start( void );
void PWM1_5_Pause( void );
void PWM1_5_Play( void );
void PWM1_5_Stop( void );

//  Funciones para PWM1_6

void PWM1_6_Set( uint32_t Valor_Lectura );
void PWM1_6_Start( void );
void PWM1_6_Pause( void );
void PWM1_6_Play( void );
void PWM1_6_Stop( void );


#endif /* end DR_PWM_H_ */
