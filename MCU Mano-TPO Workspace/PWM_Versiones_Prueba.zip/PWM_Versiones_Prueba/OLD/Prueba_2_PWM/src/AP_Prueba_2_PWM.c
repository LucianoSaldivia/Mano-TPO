/*
 * AP_PRUEBA_PWM.c
 *
 *  Created on: 4 nov. 2018
 *      Author: lsldv
 */


#define ESPERANDO_START		0
#define	ESPERANDO_STOP		1

#include "../inc/AP_Prueba_2_PWM.h"
#include "PR_Teclado.h"
#include "PR_lcd.h"
#include "PR_Relays.h"

#define RELAY0	0
#define RELAY1	1
#define RELAY2	2
#define RELAY3	3

void MDE_PRUEBA_PWM( void ){
	static uint8_t Estado = ESPERANDO_START;

	uint8_t Tecla;

	Tecla = GetKey();

	if( Tecla == NO_KEY ){
		return;
	}

	switch( Estado ){
		case ESPERANDO_START:

			if( Tecla == SW_1 || Tecla == SW_2 || Tecla == SW_3 || Tecla == SW_4 ){
				LCD_Display( "PWM Iniciado    ", LCD_RENGLON0, 0 );
				LCD_Display( "Esperando pausa ", LCD_RENGLON1, 0 );

				Relays( RELAY1, OFF );
				Relays( RELAY0, ON );

				PWM_1_Start();
				PWM_2_Start();
				PWM_3_Start();
				PWM_4_Start();
				PWM_5_Start();
				PWM_6_Start();

				Estado = ESPERANDO_STOP;
			}
			break;

		case ESPERANDO_STOP:

			if( Tecla == SW_1 || Tecla == SW_2 || Tecla == SW_3 || Tecla == SW_4 ){
				LCD_Display( "PWM Pausado     ", LCD_RENGLON0, 0 );
				LCD_Display( "Esperando play  ", LCD_RENGLON1, 0 );

				Relays( RELAY1, ON );
				Relays( RELAY0, OFF );

				PWM_1_Stop();
				PWM_2_Stop();
				PWM_3_Stop();
				PWM_4_Stop();
				PWM_5_Stop();
				PWM_6_Stop();

				Estado = ESPERANDO_START;
			}
			break;

		default:
			Estado = ESPERANDO_START;
			break;
	}



}

