/*******************************************************************************************************************************//**
 *
 * @file		PR_PWM.c
 * @brief		Descripcion del modulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/

#include "../inc/PR_PWM.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

#define CUENTAS_MINIMAS_TH       1000

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/

/*  FUNCIONES PARA TPO_INFO_2    */

void PWM_Set_Lecturas( Lecturas_Mano_4096 *Lecturas ){

    // Cargo los nuevos TH
    Buffer_TH[ CANAL_1 ] = Convertir( Lecturas->Pulgar ) + CUENTAS_MINIMAS_TH;
    Buffer_TH[ CANAL_2 ] = Convertir( Lecturas->Indice ) + CUENTAS_MINIMAS_TH;
    Buffer_TH[ CANAL_3 ] = Convertir( Lecturas->Mayor  ) + CUENTAS_MINIMAS_TH;
    Buffer_TH[ CANAL_4 ] = Convertir( Lecturas->Anular ) + CUENTAS_MINIMAS_TH;
    Buffer_TH[ CANAL_5 ] = Convertir( Lecturas->Menor  ) + CUENTAS_MINIMAS_TH;

    // Aviso que hay nuevos TH
    Buffer_NEW_TH[ CANAL_1 ] = 1;
    Buffer_NEW_TH[ CANAL_2 ] = 1;
    Buffer_NEW_TH[ CANAL_3 ] = 1;
    Buffer_NEW_TH[ CANAL_4 ] = 1;
    Buffer_NEW_TH[ CANAL_5 ] = 1;
}

uint16_t Convertir( uint16_t Lectura_4096 ){
    uint16_t Lectura_1000, Lectura_1024 = Lectura_4096 / 4;

    if( Lectura_1024 > 1024 ){
        Lectura_1024 = 1024;
    }

    if( Lectura_1024 < 501 ){
        if( Lectura_1024 < 250 ){
            if( Lectura_1024 < 125 ){
                if( Lectura_1024 < 84 ){
                    if( Lectura_1024 < 42 ){
                        Lectura_1000 = Lectura_1024;         // 0 <= Lectura_1024 < 42
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 1;     // 42 <= Lectura_1024 < 84
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 2;         // 84 <= Lectura_1024 < 125
                }
            }
            else{
                if( Lectura_1024 < 209 ){
                    if( Lectura_1024 < 167 ){
                        Lectura_1000 = Lectura_1024 - 3;     // 125 <= Lectura_1024 < 167
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 4;     // 167 <= Lectura_1024 < 209
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 5;         // 209 <= Lectura_1024 < 250
                }
            }
        }
        else{
            if( Lectura_1024 < 375 ){
                if( Lectura_1024 < 333 ){
                    if( Lectura_1024 < 292 ){
                        Lectura_1000 = Lectura_1024 - 6;     // 250 <= Lectura_1024 < 292
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 7;     // 292 <= Lectura_1024 < 333
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 8;         // 333 <= Lectura_1024 < 375
                }
            }

            else{
                if( Lectura_1024 < 459 ){
                    if( Lectura_1024 < 417 ){
                        Lectura_1000 = Lectura_1024 - 9;     // 375 <= Lectura_1024 < 417
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 10;    // 417 <= Lectura_1024 < 459
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 11;        // 459 <= Lectura_1024 < 501
                }
            }
        }
    }
    else{
        if( Lectura_1024 < 751 ){
            if( Lectura_1024 < 626 ){
                if( Lectura_1024 < 548 ){
                    if( Lectura_1024 < 542 ){
                        Lectura_1000 = Lectura_1024 - 12;    // 501 <= Lectura_1024 < 542
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 13;    // 542 <= Lectura_1024 < 548
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 14;        // 548 <= Lectura_1024 < 626
                }
            }
            else{
                if( Lectura_1024 < 709 ){
                    if( Lectura_1024 < 667 ){
                        Lectura_1000 = Lectura_1024 - 15;    // 626 <= Lectura_1024 < 667
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 16;    // 667 <= Lectura_1024 < 709
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 17;        // 709 <= Lectura_1024 < 751
                }
            }
        }
        else{
            if( Lectura_1024 < 917 ){
                if( Lectura_1024 < 834 ){
                    if( Lectura_1024 < 792 ){
                        Lectura_1000 = Lectura_1024 - 18;    // 751 <= Lectura_1024 < 792
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 19;    // 792 <= Lectura_1024 < 834
                    }
                }
                else{
                    if( Lectura_1024 < 876 ){
                        Lectura_1000 = Lectura_1024 - 20;    // 834 <= Lectura_1024 < 876
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 21;    // 876 <= Lectura_1024 < 917
                    }
                }
            }
            else{
                if( Lectura_1024 < 1000 ){
                    if( Lectura_1024 < 959 ){
                        Lectura_1000 = Lectura_1024 - 22;    // 917 <= Lectura_1024 < 959
                    }
                    else{
                        Lectura_1000 = Lectura_1024 - 23;    // 959 <= Lectura_1024 < 1000
                    }
                }
                else{
                    Lectura_1000 = Lectura_1024 - 24;        // 1000 <= Lectura_1024 < 1024
                }
            }
        }
    }

    return Lectura_1000;
}

void PWM_Get_Lecturas( Lecturas_Mano_4096 *Lecturas ){
    Lecturas->Pulgar = ( Buffer_TH[ CANAL_1 ] - CUENTAS_MINIMAS_TH ) * 4;
    Lecturas->Indice = ( Buffer_TH[ CANAL_2 ] - CUENTAS_MINIMAS_TH ) * 4;
    Lecturas->Mayor  = ( Buffer_TH[ CANAL_3 ] - CUENTAS_MINIMAS_TH ) * 4;
    Lecturas->Anular = ( Buffer_TH[ CANAL_4 ] - CUENTAS_MINIMAS_TH ) * 4;
    Lecturas->Menor  = ( Buffer_TH[ CANAL_5 ] - CUENTAS_MINIMAS_TH ) * 4;
}

void PWM_Start_5_Channels( void ){

    // Start   ==> OUTPUT ENABLE = 1

    /* HACER ALGO CON ESTO Y PARA START _ ALL _ CHANNELS*/
    /*
    PWM1TCR |= ( 0x01 << 0 );   // Counter Enable
    PWM1TCR |= ( 0x01 << 3 );   // PWM Enable
    */

    Buffer_NEW_ENABLE[ CANAL_1 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_2 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_3 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_4 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_5 ] = 1;
}

void PWM_Stop_5_Channels( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_ENABLE[ CANAL_1 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_2 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_3 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_4 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_5 ] = 0;

    /* HACER ALGO CON ESTO Y PARA STOP _ ALL _ CHANNELS*/
    /*
    PWM1TCR &= ~( 0x01 << 0 );  // Disable Counters
    PWM1TCR &= ~( 0x01 << 3 );  // Disable PWM Mode
    */

}


/*
uint32_t    Buffer_TH[];
uint8_t     Buffer_NEW_TH[];
uint8_t     Buffer_NEW_ENABLE[];
uint8_t     Buffer_NEW_DISABLE[];
*/

//  Funciones para el CANAL PWM1_1

void PWM_1_Set( uint32_t Valor_Lectura_4096 ){

    // Set     ==>  Cargo el nuevo TH en Buffer_TH
    //              Aviso que hay nuevo TH por Buffer_NEW_TH

    Buffer_TH[ CANAL_1 ] = Convertir( Valor_Lectura_4096 ) + CUENTAS_MINIMAS_TH;   // Cargo el nuevo TH
    Buffer_NEW_TH[ CANAL_1 ] = 1;           // Aviso que hay un nuevo TH
}

uint32_t PWM_1_Get( void ){
    return ( ( Buffer_TH[ CANAL_1 ] - CUENTAS_MINIMAS_TH ) * 4 );
}

void PWM_1_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_1 ] = 1;       // Enable PWM1_1 Output
}

void PWM_1_Stop( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_DISABLE[ CANAL_1 ] = 1;      // Disable PWM1_1 Output
}



//  Funciones para el CANAL PWM1_2

void PWM_2_Set( uint32_t Valor_Lectura_4096 ){

    // Set     ==>  Cargo el nuevo TH en Buffer_TH
    //              Aviso que hay nuevo TH por Buffer_NEW_TH

    Buffer_TH[ CANAL_2 ] = Convertir( Valor_Lectura_4096 ) + CUENTAS_MINIMAS_TH; // Cargo el nuevo TH
    Buffer_NEW_TH[ CANAL_2 ] = 1;           // Aviso que hay un nuevo TH
}

uint32_t PWM_2_Get( void ){
    return ( ( Buffer_TH[ CANAL_2 ] - CUENTAS_MINIMAS_TH ) * 4 );
}

void PWM_2_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_2 ] = 1;       // Enable PWM1_2 Output
}

void PWM_2_Stop( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_DISABLE[ CANAL_2 ] = 1;      // Disable PWM1_2 Output
}



//  Funciones para el CANAL PWM1_3

void PWM_3_Set( uint32_t Valor_Lectura_4096 ){

    // Set     ==>  Cargo el nuevo TH en Buffer_TH
    //              Aviso que hay nuevo TH por Buffer_NEW_TH

    Buffer_TH[ CANAL_3 ] = Convertir( Valor_Lectura_4096 ) + CUENTAS_MINIMAS_TH;   // Cargo el nuevo TH
    Buffer_NEW_TH[ CANAL_3 ] = 1;           // Aviso que hay un nuevo TH
}

uint32_t PWM_3_Get( void ){
    return ( ( Buffer_TH[ CANAL_3 ] - CUENTAS_MINIMAS_TH ) * 4 );
}

void PWM_3_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_3 ] = 1;       // Enable PWM1_3 Output
}

void PWM_3_Stop( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_DISABLE[ CANAL_3 ] = 1;      // Disable PWM1_3 Output
}



//  Funciones para el CANAL PWM1_4

void PWM_4_Set( uint32_t Valor_Lectura_4096 ){

    // Set     ==>  Cargo el nuevo TH en Buffer_TH
    //              Aviso que hay nuevo TH por Buffer_NEW_TH

    Buffer_TH[ CANAL_3 ] = Convertir( Valor_Lectura_4096 ) + CUENTAS_MINIMAS_TH;   // Cargo el nuevo TH
    Buffer_NEW_TH[ CANAL_3 ] = 1;           // Aviso que hay un nuevo TH
}

uint32_t PWM_4_Get( void ){
    return ( ( Buffer_TH[ CANAL_4 ] - CUENTAS_MINIMAS_TH ) * 4 );
}

void PWM_4_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_4 ] = 1;       // Enable PWM1_4 Output
}

void PWM_4_Stop( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_DISABLE[ CANAL_4 ] = 1;      // Disable PWM1_4 Output
}



//  Funciones para el CANAL PWM1_5

void PWM_5_Set( uint32_t Valor_Lectura_4096 ){

    // Set     ==>  Cargo el nuevo TH en Buffer_TH
    //              Aviso que hay nuevo TH por Buffer_NEW_TH

    Buffer_TH[ CANAL_5 ] = Convertir( Valor_Lectura_4096 ) + CUENTAS_MINIMAS_TH;   // Cargo el nuevo TH
    Buffer_NEW_TH[ CANAL_5 ] = 1;           // Aviso que hay un nuevo TH
}

uint32_t PWM_5_Get( void ){
    return ( ( Buffer_TH[ CANAL_5 ] - CUENTAS_MINIMAS_TH ) * 4 );
}

void PWM_5_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_5 ] = 1;       // Enable PWM1_5 Output
}

void PWM_5_Stop( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_DISABLE[ CANAL_5 ] = 1;      // Disable PWM1_5 Output
}



/*  ABAJO, TODAS LAS NO USADAS PARA EL TPO_INFO_2   */

void PWM_Start_All_Channels( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_1 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_2 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_3 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_4 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_5 ] = 1;
    Buffer_NEW_ENABLE[ CANAL_6 ] = 1;
}

void PWM_Stop_All_Channels( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_ENABLE[ CANAL_1 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_2 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_3 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_4 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_5 ] = 0;
    Buffer_NEW_ENABLE[ CANAL_6 ] = 0;

}

//  Funciones para el CANAL PWM1_6

void PWM_6_Set( uint32_t Valor_Lectura_4096 ){

    // Set     ==>  Cargo el nuevo TH en Buffer_TH
    //              Aviso que hay nuevo TH por Buffer_NEW_TH

    Buffer_TH[ CANAL_6 ] = Convertir( Valor_Lectura_4096 ) + CUENTAS_MINIMAS_TH;   // Cargo el nuevo TH
    Buffer_NEW_TH[ CANAL_6 ] = 1;           // Aviso que hay un nuevo TH
}

uint32_t PWM_6_Get( void ){
    return ( ( Buffer_TH[ CANAL_6 ] - CUENTAS_MINIMAS_TH ) * 4 );
}

void PWM_6_Start( void ){

    // Start   ==> OUTPUT ENABLE = 1

    Buffer_NEW_ENABLE[ CANAL_6 ] = 1;       // Enable PWM1_6 Output
}

void PWM_6_Stop( void ){

    // Stop    ==> ENABLE = 0

    Buffer_NEW_DISABLE[ CANAL_6 ] = 1;      // Disable PWM1_6 Output
}
