/*
 * AP_PRUEBA_PWM.h
 *
 *  Created on: 4 nov. 2018
 *      Author: lsldv
 */

#ifndef AP_PRUEBA_PWM_H_
#define AP_PRUEBA_PWM_H_

#include "PR_PWM.h"


void MDE_PRUEBA_PWM( void );

#endif /* AP_PRUEBA_PWM_H_ */
