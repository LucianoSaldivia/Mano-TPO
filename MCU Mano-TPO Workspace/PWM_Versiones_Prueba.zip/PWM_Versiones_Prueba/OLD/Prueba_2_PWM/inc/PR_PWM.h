/*******************************************************************************************************************************//**
 *
 * @file		PR_PWM.h
 * @brief		Breve descripción del objetivo del Módulo
 * @date		28 de oct. de 2018
 * @author		Saldivia, Luciano
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MODULO
 **********************************************************************************************************************************/

#ifndef PR_PWM_H_
#define PR_PWM_H_

/***********************************************************************************************************************************
 *** INCLUDES GLOBALES
 **********************************************************************************************************************************/

#include "Tipos.h"
#include "DR_PWM.h"

/***********************************************************************************************************************************
 *** DEFINES GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MACROS GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES
 **********************************************************************************************************************************/

typedef struct{
    uint16_t Pulgar;
    uint16_t Indice;
    uint16_t Mayor;
    uint16_t Anular;
    uint16_t Menor;
}Lecturas_Mano_4096;

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPOS DE FUNCIONES GLOBALES
 **********************************************************************************************************************************/
/*  Explicación

T1 Min = 1ms
T1 Max = 1ms
Div ---> 1000 Divisiones

 __________________                                      __________________
|         |||||||||                                     |         |||||||||                                     |
|   T1    || Div ||                 T0                  |   T1    || Div ||                 T0                  |
|         |||||||||_______________/    /________________|         |||||||||_______________/    /________________|
0ms       1ms     2ms                                   20ms
                                                        0ms       1ms     2ms                                   20ms

Al comenzar, la salida automaticamente se pone en HIGH. Vamos a contar desde 0 hasta "Divisiones" [2000,4000], y cuando
el contador sea igual a "Divisiones", la salida se pone en LOW

*/

/*  FUNCIONES PARA TPO_INFO_2    */

void PWM_Set_Lecturas( Lecturas_Mano_4096 *Lecturas );
uint16_t Convertir( uint16_t Lectura_4096 );
void PWM_Get_Lecturas( Lecturas_Mano_4096 *Lecturas );
void PWM_Start_5_Channels( void );
void PWM_Stop_5_Channels( void );


//  Funciones para el CANAL PWM1_1

void PWM_1_Set( uint32_t Valor_Lectura_4096 );
uint32_t PWM_1_Get( void );
void PWM_1_Start( void );
void PWM_1_Stop( void );


//  Funciones para el CANAL PWM1_2

void PWM_2_Set( uint32_t Valor_Lectura_4096 );
uint32_t PWM_2_Get( void );
void PWM_2_Start( void );
void PWM_2_Stop( void );


//  Funciones para el CANAL PWM1_3

void PWM_3_Set( uint32_t Valor_Lectura_4096 );
uint32_t PWM_3_Get( void );
void PWM_3_Start( void );
void PWM_3_Stop( void );


//  Funciones para el CANAL PWM1_4

void PWM_4_Set( uint32_t Valor_Lectura_4096 );
uint32_t PWM_4_Get( void );
void PWM_4_Start( void );
void PWM_4_Stop( void );


//  Funciones para el CANAL PWM1_5

void PWM_5_Set( uint32_t Valor_Lectura_4096 );
uint32_t PWM_5_Get( void );

void PWM_5_Start( void );
void PWM_5_Stop( void );


/*  ABAJO, TODAS LAS NO USADAS PARA EL TPO_INFO_2   */

void PWM_Start_All_Channels( void );
void PWM_Stop_All_Channels( void );

//  Funciones para el CANAL PWM1_6

void PWM_6_Set( uint32_t Valor_Lectura_4096 );
uint32_t PWM_5_Get( void );
void PWM_6_Start( void );
void PWM_6_Stop( void );







#endif /* PR_PWM_H_ */
