/*
 * AP_PruebaUART.h
 *
 *  Created on: 25 sep. 2018
 *      Author: lsldv
 */

#ifndef AP_PRUEBAUART_H_
#define AP_PRUEBAUART_H_

void MDE_UART ( void );

#endif /* AP_PRUEBAUART_H_ */
